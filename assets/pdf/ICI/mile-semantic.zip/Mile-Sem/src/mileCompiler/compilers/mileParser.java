// $ANTLR : "mileParser.g" -> "mileParser.java"$

/**
 * Parser for the Mile language.
 * 
 * @author Ricardo Soto
 * @since 1.5
 */

package mileCompiler.compilers;


import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

public class mileParser extends antlr.LLkParser       implements mileParserVocabTokenTypes
 {

protected mileParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public mileParser(TokenBuffer tokenBuf) {
  this(tokenBuf,2);
}

protected mileParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public mileParser(TokenStream lexer) {
  this(lexer,2);
}

public mileParser(ParserSharedInputState state) {
  super(state,2);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void program() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST program_AST = null;
		
		match(VAR_RW);
		var_dec();
		astFactory.addASTChild(currentAST, returnAST);
		match(BEGIN_RW);
		body();
		astFactory.addASTChild(currentAST, returnAST);
		match(END_RW);
		program_AST = (AST)currentAST.root;
		program_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PROGRAM,"PROGRAM")).add(program_AST));
		currentAST.root = program_AST;
		currentAST.child = program_AST!=null &&program_AST.getFirstChild()!=null ?
			program_AST.getFirstChild() : program_AST;
		currentAST.advanceChildToEnd();
		program_AST = (AST)currentAST.root;
		returnAST = program_AST;
	}
	
	public final void var_dec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST var_dec_AST = null;
		
		{
		_loop395:
		do {
			if ((LA(1)==NUMERIC_TYPE||LA(1)==STRING_TYPE)) {
				type();
				astFactory.addASTChild(currentAST, returnAST);
				AST tmp4_AST = null;
				tmp4_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp4_AST);
				match(IDENT);
				match(SEMICOLON);
			}
			else {
				break _loop395;
			}
			
		} while (true);
		}
		var_dec_AST = (AST)currentAST.root;
		var_dec_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(VAR_DEC,"VAR_DEC")).add(var_dec_AST));
		currentAST.root = var_dec_AST;
		currentAST.child = var_dec_AST!=null &&var_dec_AST.getFirstChild()!=null ?
			var_dec_AST.getFirstChild() : var_dec_AST;
		currentAST.advanceChildToEnd();
		var_dec_AST = (AST)currentAST.root;
		returnAST = var_dec_AST;
	}
	
	public final void body() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST body_AST = null;
		
		{
		_loop400:
		do {
			switch ( LA(1)) {
			case IDENT:
			{
				assign();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case IF_RW:
			case FOR_RW:
			{
				st();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case PRINT_RW:
			{
				print();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case READ_RW:
			{
				read();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				break _loop400;
			}
			}
		} while (true);
		}
		body_AST = (AST)currentAST.root;
		body_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(BODY,"BODY")).add(body_AST));
		currentAST.root = body_AST;
		currentAST.child = body_AST!=null &&body_AST.getFirstChild()!=null ?
			body_AST.getFirstChild() : body_AST;
		currentAST.advanceChildToEnd();
		body_AST = (AST)currentAST.root;
		returnAST = body_AST;
	}
	
	public final void type() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST type_AST = null;
		
		switch ( LA(1)) {
		case NUMERIC_TYPE:
		{
			AST tmp6_AST = null;
			tmp6_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp6_AST);
			match(NUMERIC_TYPE);
			type_AST = (AST)currentAST.root;
			break;
		}
		case STRING_TYPE:
		{
			AST tmp7_AST = null;
			tmp7_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp7_AST);
			match(STRING_TYPE);
			type_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = type_AST;
	}
	
	public final void assign() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST assign_AST = null;
		
		AST tmp8_AST = null;
		tmp8_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp8_AST);
		match(IDENT);
		AST tmp9_AST = null;
		tmp9_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp9_AST);
		match(ASSIG);
		expr();
		astFactory.addASTChild(currentAST, returnAST);
		match(SEMICOLON);
		assign_AST = (AST)currentAST.root;
		assign_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ASSIGN,"ASSIGN")).add(assign_AST));
		currentAST.root = assign_AST;
		currentAST.child = assign_AST!=null &&assign_AST.getFirstChild()!=null ?
			assign_AST.getFirstChild() : assign_AST;
		currentAST.advanceChildToEnd();
		assign_AST = (AST)currentAST.root;
		returnAST = assign_AST;
	}
	
	public final void expr() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expr_AST = null;
		
		expAND();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop413:
		do {
			if ((LA(1)==OR_RW)) {
				AST tmp11_AST = null;
				tmp11_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp11_AST);
				match(OR_RW);
				expAND();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop413;
			}
			
		} while (true);
		}
		expr_AST = (AST)currentAST.root;
		returnAST = expr_AST;
	}
	
	public final void st() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST st_AST = null;
		
		{
		switch ( LA(1)) {
		case FOR_RW:
		{
			for_st();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case IF_RW:
		{
			if_st();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		st_AST = (AST)currentAST.root;
		returnAST = st_AST;
	}
	
	public final void print() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST print_AST = null;
		
		AST tmp12_AST = null;
		tmp12_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp12_AST);
		match(PRINT_RW);
		match(LEFT_PAREN);
		AST tmp14_AST = null;
		tmp14_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp14_AST);
		match(STRING_LITERAL);
		match(COMMA);
		AST tmp16_AST = null;
		tmp16_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp16_AST);
		match(IDENT);
		match(RIGHT_PAREN);
		match(SEMICOLON);
		print_AST = (AST)currentAST.root;
		returnAST = print_AST;
	}
	
	public final void read() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST read_AST = null;
		
		AST tmp19_AST = null;
		tmp19_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp19_AST);
		match(READ_RW);
		match(LEFT_PAREN);
		AST tmp21_AST = null;
		tmp21_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp21_AST);
		match(IDENT);
		match(RIGHT_PAREN);
		match(SEMICOLON);
		read_AST = (AST)currentAST.root;
		returnAST = read_AST;
	}
	
	public final void for_st() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST for_st_AST = null;
		
		AST tmp24_AST = null;
		tmp24_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp24_AST);
		match(FOR_RW);
		for_header();
		astFactory.addASTChild(currentAST, returnAST);
		match(LEFT_BRACE);
		body();
		astFactory.addASTChild(currentAST, returnAST);
		match(RIGHT_BRACE);
		for_st_AST = (AST)currentAST.root;
		for_st_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(FOR_ST,"FOR_ST")).add(for_st_AST));
		currentAST.root = for_st_AST;
		currentAST.child = for_st_AST!=null &&for_st_AST.getFirstChild()!=null ?
			for_st_AST.getFirstChild() : for_st_AST;
		currentAST.advanceChildToEnd();
		for_st_AST = (AST)currentAST.root;
		returnAST = for_st_AST;
	}
	
	public final void if_st() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST if_st_AST = null;
		
		AST tmp27_AST = null;
		tmp27_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp27_AST);
		match(IF_RW);
		match(LEFT_PAREN);
		if_cond();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp29_AST = null;
		tmp29_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp29_AST);
		match(RIGHT_PAREN);
		match(LEFT_BRACE);
		body();
		astFactory.addASTChild(currentAST, returnAST);
		match(RIGHT_BRACE);
		{
		switch ( LA(1)) {
		case ELSE_RW:
		{
			else_st();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case END_RW:
		case IF_RW:
		case FOR_RW:
		case PRINT_RW:
		case READ_RW:
		case IDENT:
		case RIGHT_BRACE:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		if_st_AST = (AST)currentAST.root;
		if_st_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(IF_ST,"IF_ST")).add(if_st_AST));
		currentAST.root = if_st_AST;
		currentAST.child = if_st_AST!=null &&if_st_AST.getFirstChild()!=null ?
			if_st_AST.getFirstChild() : if_st_AST;
		currentAST.advanceChildToEnd();
		if_st_AST = (AST)currentAST.root;
		returnAST = if_st_AST;
	}
	
	public final void for_header() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST for_header_AST = null;
		
		match(LEFT_PAREN);
		for_init();
		astFactory.addASTChild(currentAST, returnAST);
		match(SEMICOLON);
		for_cond();
		astFactory.addASTChild(currentAST, returnAST);
		match(SEMICOLON);
		AST tmp35_AST = null;
		tmp35_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp35_AST);
		match(INT_LITERAL);
		match(RIGHT_PAREN);
		for_header_AST = (AST)currentAST.root;
		for_header_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(FOR_HEADER,"FOR_HEADER")).add(for_header_AST));
		currentAST.root = for_header_AST;
		currentAST.child = for_header_AST!=null &&for_header_AST.getFirstChild()!=null ?
			for_header_AST.getFirstChild() : for_header_AST;
		currentAST.advanceChildToEnd();
		for_header_AST = (AST)currentAST.root;
		returnAST = for_header_AST;
	}
	
	public final void for_init() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST for_init_AST = null;
		
		assign();
		astFactory.addASTChild(currentAST, returnAST);
		for_init_AST = (AST)currentAST.root;
		returnAST = for_init_AST;
	}
	
	public final void for_cond() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST for_cond_AST = null;
		
		expr();
		astFactory.addASTChild(currentAST, returnAST);
		for_cond_AST = (AST)currentAST.root;
		returnAST = for_cond_AST;
	}
	
	public final void if_cond() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST if_cond_AST = null;
		
		expr();
		astFactory.addASTChild(currentAST, returnAST);
		if_cond_AST = (AST)currentAST.root;
		returnAST = if_cond_AST;
	}
	
	public final void else_st() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST else_st_AST = null;
		
		AST tmp37_AST = null;
		tmp37_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp37_AST);
		match(ELSE_RW);
		match(LEFT_BRACE);
		body();
		astFactory.addASTChild(currentAST, returnAST);
		match(RIGHT_BRACE);
		else_st_AST = (AST)currentAST.root;
		else_st_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ELSE_ST,"ELSE_ST")).add(else_st_AST));
		currentAST.root = else_st_AST;
		currentAST.child = else_st_AST!=null &&else_st_AST.getFirstChild()!=null ?
			else_st_AST.getFirstChild() : else_st_AST;
		currentAST.advanceChildToEnd();
		else_st_AST = (AST)currentAST.root;
		returnAST = else_st_AST;
	}
	
	public final void expAND() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expAND_AST = null;
		
		expCons();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop416:
		do {
			if ((LA(1)==AND_RW)) {
				AST tmp40_AST = null;
				tmp40_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp40_AST);
				match(AND_RW);
				expCons();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop416;
			}
			
		} while (true);
		}
		expAND_AST = (AST)currentAST.root;
		returnAST = expAND_AST;
	}
	
	public final void expCons() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expCons_AST = null;
		
		expSum();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop420:
		do {
			if (((LA(1) >= EQUAL && LA(1) <= LE))) {
				{
				switch ( LA(1)) {
				case EQUAL:
				{
					AST tmp41_AST = null;
					tmp41_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp41_AST);
					match(EQUAL);
					break;
				}
				case LE_EQUAL:
				{
					AST tmp42_AST = null;
					tmp42_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp42_AST);
					match(LE_EQUAL);
					break;
				}
				case GR_EQUAL:
				{
					AST tmp43_AST = null;
					tmp43_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp43_AST);
					match(GR_EQUAL);
					break;
				}
				case NOT_EQUAL:
				{
					AST tmp44_AST = null;
					tmp44_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp44_AST);
					match(NOT_EQUAL);
					break;
				}
				case GR:
				{
					AST tmp45_AST = null;
					tmp45_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp45_AST);
					match(GR);
					break;
				}
				case LE:
				{
					AST tmp46_AST = null;
					tmp46_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp46_AST);
					match(LE);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expSum();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop420;
			}
			
		} while (true);
		}
		expCons_AST = (AST)currentAST.root;
		returnAST = expCons_AST;
	}
	
	public final void expSum() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expSum_AST = null;
		
		expProduct();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop424:
		do {
			if ((LA(1)==PLUS||LA(1)==SUB)) {
				{
				switch ( LA(1)) {
				case PLUS:
				{
					AST tmp47_AST = null;
					tmp47_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp47_AST);
					match(PLUS);
					break;
				}
				case SUB:
				{
					AST tmp48_AST = null;
					tmp48_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp48_AST);
					match(SUB);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expProduct();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop424;
			}
			
		} while (true);
		}
		expSum_AST = (AST)currentAST.root;
		returnAST = expSum_AST;
	}
	
	public final void expProduct() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expProduct_AST = null;
		
		expMinus();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop428:
		do {
			if ((LA(1)==STAR||LA(1)==SLASH)) {
				{
				switch ( LA(1)) {
				case STAR:
				{
					AST tmp49_AST = null;
					tmp49_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp49_AST);
					match(STAR);
					break;
				}
				case SLASH:
				{
					AST tmp50_AST = null;
					tmp50_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp50_AST);
					match(SLASH);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expMinus();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop428;
			}
			
		} while (true);
		}
		expProduct_AST = (AST)currentAST.root;
		returnAST = expProduct_AST;
	}
	
	public final void expMinus() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expMinus_AST = null;
		
		switch ( LA(1)) {
		case SUB:
		{
			{
			match(SUB);
			expNot();
			astFactory.addASTChild(currentAST, returnAST);
			}
			expMinus_AST = (AST)currentAST.root;
			expMinus_AST=(AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(UN_MINUS,"UN_MINUS")).add(expMinus_AST)) ;
			currentAST.root = expMinus_AST;
			currentAST.child = expMinus_AST!=null &&expMinus_AST.getFirstChild()!=null ?
				expMinus_AST.getFirstChild() : expMinus_AST;
			currentAST.advanceChildToEnd();
			expMinus_AST = (AST)currentAST.root;
			break;
		}
		case NOT_RW:
		case INT_LITERAL:
		case REAL_LITERAL:
		case IDENT:
		case LEFT_PAREN:
		case PLUS:
		{
			{
			{
			switch ( LA(1)) {
			case PLUS:
			{
				match(PLUS);
				break;
			}
			case NOT_RW:
			case INT_LITERAL:
			case REAL_LITERAL:
			case IDENT:
			case LEFT_PAREN:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			expNot();
			astFactory.addASTChild(currentAST, returnAST);
			}
			expMinus_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = expMinus_AST;
	}
	
	public final void expNot() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expNot_AST = null;
		
		{
		switch ( LA(1)) {
		case NOT_RW:
		{
			AST tmp53_AST = null;
			tmp53_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp53_AST);
			match(NOT_RW);
			break;
		}
		case INT_LITERAL:
		case REAL_LITERAL:
		case IDENT:
		case LEFT_PAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case IDENT:
		{
			AST tmp54_AST = null;
			tmp54_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp54_AST);
			match(IDENT);
			break;
		}
		case INT_LITERAL:
		case REAL_LITERAL:
		{
			lit();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LEFT_PAREN:
		{
			{
			match(LEFT_PAREN);
			expr();
			astFactory.addASTChild(currentAST, returnAST);
			match(RIGHT_PAREN);
			}
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		expNot_AST = (AST)currentAST.root;
		returnAST = expNot_AST;
	}
	
	public final void lit() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST lit_AST = null;
		
		switch ( LA(1)) {
		case REAL_LITERAL:
		{
			AST tmp57_AST = null;
			tmp57_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp57_AST);
			match(REAL_LITERAL);
			lit_AST = (AST)currentAST.root;
			break;
		}
		case INT_LITERAL:
		{
			AST tmp58_AST = null;
			tmp58_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp58_AST);
			match(INT_LITERAL);
			lit_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = lit_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"numeric\"",
		"\"string\"",
		"\"var\"",
		"\"begin\"",
		"\"end\"",
		"\"if\"",
		"\"else\"",
		"\"for\"",
		"\"or\"",
		"\"and\"",
		"\"not\"",
		"\"print\"",
		"\"read\"",
		"\"true\"",
		"\"false\"",
		"INT_LITERAL",
		"REAL_LITERAL",
		"LETTER",
		"DIGIT",
		"UNDERSCORE",
		"IDENT",
		"SEMICOLON",
		"COMMA",
		"DOT",
		"COLON",
		"LEFT_PAREN",
		"RIGHT_PAREN",
		"LEFT_BRACE",
		"RIGHT_BRACE",
		"LEFT_BRACKET",
		"a right bracket (']')",
		"PLUS",
		"SUB",
		"STAR",
		"SLASH",
		"ASSIG",
		"EQUAL",
		"NOT_EQUAL",
		"GR_EQUAL",
		"LE_EQUAL",
		"GR",
		"LE",
		"NUMBER",
		"WS",
		"STRING_LITERAL",
		"LINE_COMMENT",
		"COMMENT",
		"PROGRAM",
		"VAR_DEC",
		"UN_MINUS",
		"BODY",
		"ASSIGN",
		"FOR_ST",
		"IF_ST",
		"ELSE_ST",
		"FOR_HEADER"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	
	}
