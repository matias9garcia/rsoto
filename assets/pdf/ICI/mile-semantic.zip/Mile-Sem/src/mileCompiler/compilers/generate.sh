java antlr.Tool SQLLexer.g
java antlr.Tool SQLParser.g
java antlr.Tool SQLTreeParser.g

