package mileCompiler.compilers;

import java.util.ArrayList;

import antlr.collections.AST;

/**
 * Performs the semantic checking for the Mile language.
 * 
 * 
 * @author Ricardo Soto<br>
 * @since 1.5<br>
 */

public class SemanticInspector {
    
	private ArrayList<String> symbolTable = new ArrayList<String>();

	/**
	 * Add the variable to the symbol table 
	 * 
	 * @param var
	 *           the AST containing the variable.
	 */ 
	public void addVar(AST var) {

		if(symbolTable.contains(var.toString()))
			this.semanticError(var, "redefinition of variable '" + var + "'");
		else
			symbolTable.add(var.toString());

	}

	/**
	 * Add the variable to the symbol table 
	 * 
	 * @param var
	 *           the AST containing the variable.
	 */ 
	public void checkVar(AST var) {
		if(!symbolTable.contains(var.toString()))
			this.semanticError(var, "variable '" + var + "' is not defined");

	}
	
	public void semanticError(AST ast, String message)  {
		System.err.println(ast.getFilename() + ":" + 
				ast.getLine() + ":" + 
				ast.getColumn() + ": " + 
				message);
	} 
        
 
    
}


 