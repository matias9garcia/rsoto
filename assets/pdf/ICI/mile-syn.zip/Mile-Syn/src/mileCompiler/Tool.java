package mileCompiler;

import java.io.FileInputStream;


import antlr.collections.AST;
import antlr.debug.misc.ASTFrame;
import mileCompiler.compilers.mileLexer;
import mileCompiler.compilers.mileParser;


/**
 * The main class of the Mile Language
 * 
 * @author Ricardo Soto
 * @since 1.5
 */


public class Tool {

    private static String fileName = "";
    private static FileInputStream fis = null;

    public static void main(String args[]) { 
        try { 
            System.out.println("Parsing file...");
            setSourceFile(args);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Set source file and arguments.
     * 
     * @param args
     */
    public static void setSourceFile(String args[]) {
        int i = args.length - 1;
        try {
            setFileName(args[i]);
            setFis(new FileInputStream(args[i])); 
            SyntacticTest();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    
    /**
     * Test our lexer.
     * 
     * @param args
     */
    public static void SyntacticTest() {
    	try
    	{
    		mileLexer lexer = new mileLexer(fis);
    		lexer.setFilename(fileName);
    		lexer.setTokenObjectClass("antlraux.util.LexInfoToken");
    		mileParser parser = new mileParser(lexer);
            parser.setFilename(fileName);
            parser.program();
            AST ast = parser.getAST();
            final ASTFrame frame1 = new ASTFrame("", ast);
            frame1.setVisible(true);	
    	}
    	catch (Exception ex)
    	{
    		System.err.println("Error: " + ex.toString());
    	}
    }


    /**
     * @param fis The fis to set.
     */
    public static void setFis(FileInputStream fisIn) {
        fis = fisIn;
    }

    /**
     * @param fileName The fileName to set.
     */
    public static void setFileName(String fileNameIn) {
        fileName = fileNameIn;
    }

}

