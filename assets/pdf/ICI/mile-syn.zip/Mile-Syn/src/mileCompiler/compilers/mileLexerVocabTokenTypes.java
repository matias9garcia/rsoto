// $ANTLR : "mileLexer.g" -> "mileLexer.java"$

/**
 * Lexer for the Mile language.
 * 
 * @author Ricardo Soto
 * @since 1.5
 */

package mileCompiler.compilers;

public interface mileLexerVocabTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int NUMERIC_TYPE = 4;
	int STRING_TYPE = 5;
	int VAR_RW = 6;
	int BEGIN_RW = 7;
	int END_RW = 8;
	int IF_RW = 9;
	int ELSE_RW = 10;
	int FOR_RW = 11;
	int OR_RW = 12;
	int AND_RW = 13;
	int NOT_RW = 14;
	int PRINT_RW = 15;
	int READ_RW = 16;
	int TRUE_LITERAL = 17;
	int FALSE_LITERAL = 18;
	int INT_LITERAL = 19;
	int REAL_LITERAL = 20;
	int LETTER = 21;
	int DIGIT = 22;
	int UNDERSCORE = 23;
	int IDENT = 24;
	int SEMICOLON = 25;
	int COMMA = 26;
	int DOT = 27;
	int COLON = 28;
	int LEFT_PAREN = 29;
	int RIGHT_PAREN = 30;
	int LEFT_BRACE = 31;
	int RIGHT_BRACE = 32;
	int LEFT_BRACKET = 33;
	int RIGHT_BRACKET = 34;
	int PLUS = 35;
	int SUB = 36;
	int STAR = 37;
	int SLASH = 38;
	int ASSIG = 39;
	int EQUAL = 40;
	int NOT_EQUAL = 41;
	int GR_EQUAL = 42;
	int LE_EQUAL = 43;
	int GR = 44;
	int LE = 45;
	int NUMBER = 46;
	int WS = 47;
	int STRING_LITERAL = 48;
	int LINE_COMMENT = 49;
	int COMMENT = 50;
}
