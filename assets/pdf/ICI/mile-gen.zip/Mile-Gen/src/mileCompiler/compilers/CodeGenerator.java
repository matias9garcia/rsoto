package mileCompiler.compilers;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import antlr.collections.AST;

/**
 * Performs the code generation for the Mile language.
 * 
 * 
 * @author Ricardo Soto<br>
 * @since 1.5<br>
 */

public class CodeGenerator {
    
	
	private PrintWriter pW = null;
    protected String code = "";
    static private String PATH = "output/";
    private String fileName = "test";
    
    public CodeGenerator() {
        this.buildFile();
    }
    
    public void buildFile() {
        this.createFile(PATH + fileName + ".c");
    }
    
    public void addHeader() {
    	pW.println("#include <stdio.h>");
    	pW.println("");
    	pW.println("void main()");
    	pW.println("{");
 
    	
    }

    public void addVar(AST type, AST id) {
    	String st = "";
    	if(type.toString().equals("numeric")) {
    		st = "  int " + id + ";";
    	} else {
    		st = "  char *" + id + ";";
        }
    	pW.println(st);
    }	
 
    
    public void end() {
    	pW.println("}");
       	this.closeFile();
    	
    }
 
    /**
     * Associates the print writer to an output file, the file name is given.
     *
     * @param st
     *            the name of the file
     */
    public void createFile(String st) {
        try {  
            FileWriter fW = new FileWriter(st);
            BufferedWriter bW = new BufferedWriter(fW);
            pW = new PrintWriter(bW);
        } catch (IOException ioe) {
            System.err.println("Path does not exist: '" + st + "'");
        }
    }

    /**
     * Closes the output file.
     */
    public void closeFile() {
    	pW.close();
    }

	
    
}


 