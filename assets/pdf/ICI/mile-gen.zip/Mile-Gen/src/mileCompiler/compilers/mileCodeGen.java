// $ANTLR : "mileCodeGen.g" -> "mileCodeGen.java"$

/**
 * Semantic analysis for the Mile Language.
 * 
 * @author Ricardo Soto
 * @since 1.5
 */

package mileCompiler.compilers;


import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


public class mileCodeGen extends antlr.TreeParser       implements mileCodeGenTokenTypes
 {

private CodeGenerator   cG = new CodeGenerator();
public mileCodeGen() {
	tokenNames = _tokenNames;
}

	public final void program(AST _t) throws RecognitionException {
		
		AST program_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t2 = _t;
		AST tmp1_AST_in = (AST)_t;
		match(_t,PROGRAM);
		_t = _t.getFirstChild();
		cG.addHeader();
		var_dec(_t);
		_t = _retTree;
		body(_t);
		_t = _retTree;
		cG.end();
		_t = __t2;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void var_dec(AST _t) throws RecognitionException {
		
		AST var_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST t = null;
		AST id = null;
		
		AST __t4 = _t;
		AST tmp2_AST_in = (AST)_t;
		match(_t,VAR_DEC);
		_t = _t.getFirstChild();
		{
		_loop6:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==NUMERIC_TYPE||_t.getType()==STRING_TYPE)) {
				t = _t==ASTNULL ? null : (AST)_t;
				type(_t);
				_t = _retTree;
				id = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				cG.addVar(t,id);
			}
			else {
				break _loop6;
			}
			
		} while (true);
		}
		_t = __t4;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void body(AST _t) throws RecognitionException {
		
		AST body_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t9 = _t;
		AST tmp3_AST_in = (AST)_t;
		match(_t,BODY);
		_t = _t.getFirstChild();
		assign(_t);
		_t = _retTree;
		_t = __t9;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void type(AST _t) throws RecognitionException {
		
		AST type_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case NUMERIC_TYPE:
		{
			AST tmp4_AST_in = (AST)_t;
			match(_t,NUMERIC_TYPE);
			_t = _t.getNextSibling();
			break;
		}
		case STRING_TYPE:
		{
			AST tmp5_AST_in = (AST)_t;
			match(_t,STRING_TYPE);
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void assign(AST _t) throws RecognitionException {
		
		AST assign_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST id = null;
		
		AST __t11 = _t;
		AST tmp6_AST_in = (AST)_t;
		match(_t,ASSIGN);
		_t = _t.getFirstChild();
		{
		id = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		AST tmp7_AST_in = (AST)_t;
		match(_t,ASSIG);
		_t = _t.getNextSibling();
		expr(_t);
		_t = _retTree;
		}
		_t = __t11;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void expr(AST _t) throws RecognitionException {
		
		AST expr_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case OR_RW:
		{
			AST __t14 = _t;
			AST tmp8_AST_in = (AST)_t;
			match(_t,OR_RW);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t14;
			_t = _t.getNextSibling();
			break;
		}
		case AND_RW:
		{
			AST __t15 = _t;
			AST tmp9_AST_in = (AST)_t;
			match(_t,AND_RW);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t15;
			_t = _t.getNextSibling();
			break;
		}
		case EQUAL:
		{
			AST __t16 = _t;
			AST tmp10_AST_in = (AST)_t;
			match(_t,EQUAL);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t16;
			_t = _t.getNextSibling();
			break;
		}
		case GR_EQUAL:
		{
			AST __t17 = _t;
			AST tmp11_AST_in = (AST)_t;
			match(_t,GR_EQUAL);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t17;
			_t = _t.getNextSibling();
			break;
		}
		case NOT_EQUAL:
		{
			AST __t18 = _t;
			AST tmp12_AST_in = (AST)_t;
			match(_t,NOT_EQUAL);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t18;
			_t = _t.getNextSibling();
			break;
		}
		case GR:
		{
			AST __t19 = _t;
			AST tmp13_AST_in = (AST)_t;
			match(_t,GR);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t19;
			_t = _t.getNextSibling();
			break;
		}
		case LE:
		{
			AST __t20 = _t;
			AST tmp14_AST_in = (AST)_t;
			match(_t,LE);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t20;
			_t = _t.getNextSibling();
			break;
		}
		case PLUS:
		{
			AST __t21 = _t;
			AST tmp15_AST_in = (AST)_t;
			match(_t,PLUS);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t21;
			_t = _t.getNextSibling();
			break;
		}
		case SUB:
		{
			AST __t22 = _t;
			AST tmp16_AST_in = (AST)_t;
			match(_t,SUB);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t22;
			_t = _t.getNextSibling();
			break;
		}
		case STAR:
		{
			AST __t23 = _t;
			AST tmp17_AST_in = (AST)_t;
			match(_t,STAR);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t23;
			_t = _t.getNextSibling();
			break;
		}
		case SLASH:
		{
			AST __t24 = _t;
			AST tmp18_AST_in = (AST)_t;
			match(_t,SLASH);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t24;
			_t = _t.getNextSibling();
			break;
		}
		case UN_MINUS:
		{
			AST __t25 = _t;
			AST tmp19_AST_in = (AST)_t;
			match(_t,UN_MINUS);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			_t = __t25;
			_t = _t.getNextSibling();
			break;
		}
		case RES_NOT:
		{
			AST __t26 = _t;
			AST tmp20_AST_in = (AST)_t;
			match(_t,RES_NOT);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			_t = __t26;
			_t = _t.getNextSibling();
			break;
		}
		case IDENT:
		{
			AST tmp21_AST_in = (AST)_t;
			match(_t,IDENT);
			_t = _t.getNextSibling();
			break;
		}
		case INT_LITERAL:
		case REAL_LITERAL:
		{
			lit(_t);
			_t = _retTree;
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void lit(AST _t) throws RecognitionException {
		
		AST lit_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case REAL_LITERAL:
		{
			AST tmp22_AST_in = (AST)_t;
			match(_t,REAL_LITERAL);
			_t = _t.getNextSibling();
			break;
		}
		case INT_LITERAL:
		{
			AST tmp23_AST_in = (AST)_t;
			match(_t,INT_LITERAL);
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"numeric\"",
		"\"string\"",
		"\"var\"",
		"\"begin\"",
		"\"end\"",
		"\"if\"",
		"\"else\"",
		"\"for\"",
		"\"or\"",
		"\"and\"",
		"\"not\"",
		"\"print\"",
		"\"read\"",
		"\"true\"",
		"\"false\"",
		"INT_LITERAL",
		"REAL_LITERAL",
		"LETTER",
		"DIGIT",
		"UNDERSCORE",
		"IDENT",
		"SEMICOLON",
		"COMMA",
		"DOT",
		"COLON",
		"LEFT_PAREN",
		"RIGHT_PAREN",
		"LEFT_BRACE",
		"RIGHT_BRACE",
		"LEFT_BRACKET",
		"a right bracket (']')",
		"PLUS",
		"SUB",
		"STAR",
		"SLASH",
		"ASSIG",
		"EQUAL",
		"NOT_EQUAL",
		"GR_EQUAL",
		"LE_EQUAL",
		"GR",
		"LE",
		"NUMBER",
		"WS",
		"STRING_LITERAL",
		"LINE_COMMENT",
		"COMMENT",
		"PROGRAM",
		"VAR_DEC",
		"UN_MINUS",
		"BODY",
		"ASSIGN",
		"FOR_ST",
		"IF_ST",
		"ELSE_ST",
		"FOR_HEADER",
		"RES_NOT"
	};
	
	}
	
