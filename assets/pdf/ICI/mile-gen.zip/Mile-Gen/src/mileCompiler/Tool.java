package mileCompiler;

import java.io.FileInputStream;

import antlr.collections.AST;
//import antlr.debug.misc.ASTFrame;
import mileCompiler.compilers.mileLexer;
import mileCompiler.compilers.mileParser;
import mileCompiler.compilers.mileTreeParser;
import mileCompiler.compilers.mileCodeGen;


/**
 * The main class of the Mile Language
 * 
 * @author Ricardo Soto
 * @since 1.5
 */


public class Tool {

    private static String fileName = "";
    private static FileInputStream fis = null;

    public static void main(String args[]) { 
        try { 
            setSourceFile(args);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Set source file and arguments.
     * 
     * @param args
     */
    public static void setSourceFile(String args[]) {
        int i = args.length - 1;
        try {
            setFileName(args[i]);
            setFis(new FileInputStream(args[i])); 
            CodeGenerationTest();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    
    /**
     * Test our lexer.
     * 
     * @param args
     */
    public static void CodeGenerationTest() {
    	try
    	{
    		System.out.println("Parsing file...");
    		mileLexer lexer = new mileLexer(fis);
    		lexer.setFilename(fileName);
    		lexer.setTokenObjectClass("antlraux.util.LexInfoToken");
    		mileParser parser = new mileParser(lexer);
            parser.setFilename(fileName);
            parser.program();
            AST ast = parser.getAST();
            //final ASTFrame frame1 = new ASTFrame("", ast);
            //frame1.setVisible(true);
            
            System.out.println("Semantic Checking...");
            mileTreeParser treeParser = new mileTreeParser();
            treeParser.program(ast);
            
            System.out.println("Code Generation...");
            mileCodeGen codeGen = new mileCodeGen();
            codeGen.program(ast);
            System.out.println("Ok...");
            
    	}
    	catch (Exception ex)
    	{
    		System.err.println("Error leyendo tokens: " + ex.toString());
    	}
    }


    /**
     * @param fis The fis to set.
     */
    public static void setFis(FileInputStream fisIn) {
        fis = fisIn;
    }

    /**
     * @param fileName The fileName to set.
     */
    public static void setFileName(String fileNameIn) {
        fileName = fileNameIn;
    }

}

