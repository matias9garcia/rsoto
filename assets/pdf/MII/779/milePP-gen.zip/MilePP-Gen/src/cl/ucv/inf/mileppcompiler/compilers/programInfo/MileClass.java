package cl.ucv.inf.mileppcompiler.compilers.programInfo;

import java.util.ArrayList;

/**
 * Stores the intermediate representation of a Mile++ class.
 *  
 * @author Ricardo Soto<br>
 * @since 1.5<br>
 */

public class MileClass {

	private String id;
	private ArrayList<MileAttribute> mileAttributes = new ArrayList<MileAttribute>();
	private ArrayList<MileMethod> mileMethods = new ArrayList<MileMethod>();
	
	/**
	 * @param id
	 */
	public MileClass(String id) {
		super();
		this.id = id;
	}

	/**
	 * Adds an attribute to the class
	 * 
	 * @param a
	 *           the mileAttribute.
	 */ 
	public void addAtt(MileAttribute a){
		this.mileAttributes.add(a);
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the mileAttributes
	 */
	public ArrayList<MileAttribute> getMileAttributes() {
		return mileAttributes;
	}

	/**
	 * @param mileAttributes the mileAttributes to set
	 */
	public void setMileAttributes(ArrayList<MileAttribute> mileAttributes) {
		this.mileAttributes = mileAttributes;
	}

	/**
	 * @return the mileMethods
	 */
	public ArrayList<MileMethod> getMileMethods() {
		return mileMethods;
	}

	/**
	 * @param mileMethods the mileMethods to set
	 */
	public void setMileMethods(ArrayList<MileMethod> mileMethods) {
		this.mileMethods = mileMethods;
	}
	
	
	public void setAttributeValue(String idAtt, String value) {
		MileAttribute mA = getAttFromId(idAtt);
		if(mA!=null)
			mA.setValue(Integer.parseInt(value));	
	}
	
	public void addAttribute(String idAtt) {
		this.mileAttributes.add(new MileAttribute(idAtt));	
	}
	
	public MileAttribute getAttFromId(String idAtt) {
		for(MileAttribute mA : this.getMileAttributes())
			if(mA.getId().equals(idAtt))
				return mA;
		return null;		
	}

	public boolean containsAtt(String idAtt) {
		for(MileAttribute mA : this.getMileAttributes())
			if(mA.getId().equals(idAtt))
				return true;
		return false;		
	}

	public String toString(){
		String st= id + "";
		for (MileAttribute mA : this.getMileAttributes()) 
			st+= "[" + mA.toString() + "]";
		return st;
	}
	
	
}
