package cl.ucv.inf.mileppcompiler.compilers.programInfo;

import java.io.FileInputStream;

//import cl.ucv.inf.mileppcompiler.compilers.ExpTreeParser;
import cl.ucv.inf.mileppcompiler.compilers.MilePPTreeParser2ndPass;

import antlr.collections.AST;

/**
 * Stores the intermediate representation of a Mile++ method.
 * 
 * @author Ricardo Soto<br>
 * @since 1.5<br>
 */

public class MileMethod {

	private String id;
	private AST ast;
	private String code;
	
	
	
	/**
	 * @param id
	 * @param ast
	 */
	public MileMethod(String id, AST ast) {
		super();
		this.id = id;
		this.ast = ast;
	}
	
	/**
	 * 
	 
	public void propagateConstants() {
		String st = generateCodeWithPropConstants();
		this.setAst(reBuildASTWithPropConstants(st));
	}
	
	public String generateCodeWithPropConstants() {
		  ExpTreeParser eTP = new ExpTreeParser();
          eTP.expr(ast);
          return eTP.getCode();
          
	}
	
	public AST reBuildASTWithPropConstants(String st) {
		ExpTreeParser eTP = new ExpTreeParser();
        eTP.expr(ast);
        return eTP.getCode();
        
	}
	
	*/
	
	
	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * @return the ast
	 */
	public AST getAst() {
		return ast;
	}
	/**
	 * @param ast the ast to set
	 */
	public void setAst(AST ast) {
		this.ast = ast;
	}
	/**
	 * @return the code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}
	
	
	
	
	
}
