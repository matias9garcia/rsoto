package cl.ucv.inf.mileppcompiler.compilers.programInfo;

/**
 * Stores the intermediate representation of a Mile++ attribute.
 * 
 * 
 * @author Ricardo Soto<br>
 * @since 1.5<br>
 */

public class MileAttribute {

	private String id ;
	private Integer value = null ;

	/**
	 * @param id
	 */
	public MileAttribute(String id) {
		super();
		this.id = id;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the value
	 */
	public Integer getValue() {
		return value;
	}

	/**
	 * @param value the value to set
	 */
	public void setValue(Integer value) {
		this.value = value;
	}
	
	public String toString(){
		return id + ":" + value;
	}
	
	
}
