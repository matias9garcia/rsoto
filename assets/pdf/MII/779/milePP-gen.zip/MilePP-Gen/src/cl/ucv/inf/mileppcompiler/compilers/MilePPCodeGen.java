// $ANTLR : "MilePPCodeGen.g" -> "MilePPCodeGen.java"$

/**
 * Semantic analysis for the Mile Language.
 * 
 * @author Ricardo Soto
 * @since 1.5
 */

package cl.ucv.inf.mileppcompiler.compilers;


import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


public class MilePPCodeGen extends antlr.TreeParser       implements MilePPCodeGenTokenTypes
 {

private CodeGenerator   cG = new CodeGenerator();
private String classId = "";

	public void setId(AST id) {
		this.classId = id.toString();
	}
	
	public String getId() {
		return classId;
	}
public MilePPCodeGen() {
	tokenNames = _tokenNames;
}

	public final void program(AST _t) throws RecognitionException {
		
		AST program_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t67 = _t;
		AST tmp1_AST_in = (AST)_t;
		match(_t,PROGRAM);
		_t = _t.getFirstChild();
		main_class_dec(_t);
		_t = _retTree;
		{
		_loop69:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==CLASS_RW)) {
				class_dec(_t);
				_t = _retTree;
			}
			else {
				break _loop69;
			}
			
		} while (true);
		}
		cG.end();
		_t = __t67;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void main_class_dec(AST _t) throws RecognitionException {
		
		AST main_class_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t71 = _t;
		AST tmp2_AST_in = (AST)_t;
		match(_t,MAIN_RW);
		_t = _t.getFirstChild();
		class_dec(_t);
		_t = _retTree;
		_t = __t71;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void class_dec(AST _t) throws RecognitionException {
		
		AST class_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST id1 = null;
		
		AST __t73 = _t;
		AST tmp3_AST_in = (AST)_t;
		match(_t,CLASS_RW);
		_t = _t.getFirstChild();
		id1 = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		cG.addClass(id1);this.setId(id1);
		{
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case EXTENDS_RW:
		{
			AST tmp4_AST_in = (AST)_t;
			match(_t,EXTENDS_RW);
			_t = _t.getNextSibling();
			AST tmp5_AST_in = (AST)_t;
			match(_t,IDENT);
			_t = _t.getNextSibling();
			break;
		}
		case BODY:
		case PARAM:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		}
		{
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case PARAM:
		{
			param(_t);
			_t = _retTree;
			break;
		}
		case BODY:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		}
		class_body(_t);
		_t = _retTree;
		cG.endClass();
		_t = __t73;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void param(AST _t) throws RecognitionException {
		
		AST param_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t77 = _t;
		AST tmp6_AST_in = (AST)_t;
		match(_t,PARAM);
		_t = _t.getFirstChild();
		type(_t);
		_t = _retTree;
		AST tmp7_AST_in = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		{
		_loop79:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==COMMA)) {
				AST tmp8_AST_in = (AST)_t;
				match(_t,COMMA);
				_t = _t.getNextSibling();
				type(_t);
				_t = _retTree;
				AST tmp9_AST_in = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
			}
			else {
				break _loop79;
			}
			
		} while (true);
		}
		_t = __t77;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void class_body(AST _t) throws RecognitionException {
		
		AST class_body_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t81 = _t;
		AST tmp10_AST_in = (AST)_t;
		match(_t,BODY);
		_t = _t.getFirstChild();
		var_dec(_t);
		_t = _retTree;
		method_dec(_t);
		_t = _retTree;
		_t = __t81;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void type(AST _t) throws RecognitionException {
		
		AST type_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case NUMERIC_TYPE:
		case STRING_TYPE:
		{
			basic_type(_t);
			_t = _retTree;
			break;
		}
		case IDENT:
		{
			AST tmp11_AST_in = (AST)_t;
			match(_t,IDENT);
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void var_dec(AST _t) throws RecognitionException {
		
		AST var_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t83 = _t;
		AST tmp12_AST_in = (AST)_t;
		match(_t,VAR_DEC);
		_t = _t.getFirstChild();
		{
		_loop85:
		do {
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BASIC_VAR_DEC:
			{
				basic_var_dec(_t);
				_t = _retTree;
				break;
			}
			case OBJECT_RW:
			{
				object_dec(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				break _loop85;
			}
			}
		} while (true);
		}
		_t = __t83;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void method_dec(AST _t) throws RecognitionException {
		
		AST method_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST t = null;
		AST id2 = null;
		
		AST __t94 = _t;
		AST tmp13_AST_in = (AST)_t;
		match(_t,METHOD_RW);
		_t = _t.getFirstChild();
		{
		_loop97:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==NUMERIC_TYPE||_t.getType()==STRING_TYPE||_t.getType()==IDENT)) {
				t = _t==ASTNULL ? null : (AST)_t;
				type(_t);
				_t = _retTree;
				id2 = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				cG.addMethod(t,id2);
				{
				if (_t==null) _t=ASTNULL;
				switch ( _t.getType()) {
				case PARAM:
				{
					param(_t);
					_t = _retTree;
					break;
				}
				case VAR_DEC:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(_t);
				}
				}
				}
				var_dec(_t);
				_t = _retTree;
				body(_t);
				_t = _retTree;
				return_st(_t);
				_t = _retTree;
				cG.endMethod();
			}
			else {
				break _loop97;
			}
			
		} while (true);
		}
		_t = __t94;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void basic_var_dec(AST _t) throws RecognitionException {
		
		AST basic_var_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t87 = _t;
		AST tmp14_AST_in = (AST)_t;
		match(_t,BASIC_VAR_DEC);
		_t = _t.getFirstChild();
		basic_type(_t);
		_t = _retTree;
		AST tmp15_AST_in = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		_t = __t87;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void object_dec(AST _t) throws RecognitionException {
		
		AST object_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t89 = _t;
		AST tmp16_AST_in = (AST)_t;
		match(_t,OBJECT_RW);
		_t = _t.getFirstChild();
		AST tmp17_AST_in = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		AST tmp18_AST_in = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		_t = __t89;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void basic_type(AST _t) throws RecognitionException {
		
		AST basic_type_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		{
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case NUMERIC_TYPE:
		{
			AST tmp19_AST_in = (AST)_t;
			match(_t,NUMERIC_TYPE);
			_t = _t.getNextSibling();
			break;
		}
		case STRING_TYPE:
		{
			AST tmp20_AST_in = (AST)_t;
			match(_t,STRING_TYPE);
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		}
		_retTree = _t;
	}
	
	public final void body(AST _t) throws RecognitionException {
		
		AST body_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t101 = _t;
		AST tmp21_AST_in = (AST)_t;
		match(_t,BODY);
		_t = _t.getFirstChild();
		{
		_loop103:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==ASSIGN)) {
				assign(_t);
				_t = _retTree;
			}
			else {
				break _loop103;
			}
			
		} while (true);
		}
		_t = __t101;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void return_st(AST _t) throws RecognitionException {
		
		AST return_st_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t99 = _t;
		AST tmp22_AST_in = (AST)_t;
		match(_t,RETURN_RW);
		_t = _t.getFirstChild();
		cG.addReturn();
		expr(_t);
		_t = _retTree;
		cG.endReturn();
		_t = __t99;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void expr(AST _t) throws RecognitionException {
		
		AST expr_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case OR_RW:
		{
			AST __t107 = _t;
			AST tmp23_AST_in = (AST)_t;
			match(_t,OR_RW);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t107;
			_t = _t.getNextSibling();
			break;
		}
		case AND_RW:
		{
			AST __t108 = _t;
			AST tmp24_AST_in = (AST)_t;
			match(_t,AND_RW);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t108;
			_t = _t.getNextSibling();
			break;
		}
		case EQUAL:
		{
			AST __t109 = _t;
			AST tmp25_AST_in = (AST)_t;
			match(_t,EQUAL);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t109;
			_t = _t.getNextSibling();
			break;
		}
		case GR_EQUAL:
		{
			AST __t110 = _t;
			AST tmp26_AST_in = (AST)_t;
			match(_t,GR_EQUAL);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t110;
			_t = _t.getNextSibling();
			break;
		}
		case NOT_EQUAL:
		{
			AST __t111 = _t;
			AST tmp27_AST_in = (AST)_t;
			match(_t,NOT_EQUAL);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t111;
			_t = _t.getNextSibling();
			break;
		}
		case GR:
		{
			AST __t112 = _t;
			AST tmp28_AST_in = (AST)_t;
			match(_t,GR);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t112;
			_t = _t.getNextSibling();
			break;
		}
		case LE:
		{
			AST __t113 = _t;
			AST tmp29_AST_in = (AST)_t;
			match(_t,LE);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t113;
			_t = _t.getNextSibling();
			break;
		}
		case PLUS:
		{
			AST __t114 = _t;
			AST tmp30_AST_in = (AST)_t;
			match(_t,PLUS);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			cG.addPlus();
			expr(_t);
			_t = _retTree;
			_t = __t114;
			_t = _t.getNextSibling();
			break;
		}
		case SUB:
		{
			AST __t115 = _t;
			AST tmp31_AST_in = (AST)_t;
			match(_t,SUB);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t115;
			_t = _t.getNextSibling();
			break;
		}
		case STAR:
		{
			AST __t116 = _t;
			AST tmp32_AST_in = (AST)_t;
			match(_t,STAR);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t116;
			_t = _t.getNextSibling();
			break;
		}
		case SLASH:
		{
			AST __t117 = _t;
			AST tmp33_AST_in = (AST)_t;
			match(_t,SLASH);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t117;
			_t = _t.getNextSibling();
			break;
		}
		case UN_MINUS:
		{
			AST __t118 = _t;
			AST tmp34_AST_in = (AST)_t;
			match(_t,UN_MINUS);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			_t = __t118;
			_t = _t.getNextSibling();
			break;
		}
		case RES_NOT:
		{
			AST __t119 = _t;
			AST tmp35_AST_in = (AST)_t;
			match(_t,RES_NOT);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			_t = __t119;
			_t = _t.getNextSibling();
			break;
		}
		case IDENT:
		{
			AST tmp36_AST_in = (AST)_t;
			match(_t,IDENT);
			_t = _t.getNextSibling();
			break;
		}
		case INT_LITERAL:
		case REAL_LITERAL:
		{
			lit(_t);
			_t = _retTree;
			break;
		}
		case ACCESS:
		{
			access(_t);
			_t = _retTree;
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void assign(AST _t) throws RecognitionException {
		
		AST assign_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST id1 = null;
		
		AST __t105 = _t;
		AST tmp37_AST_in = (AST)_t;
		match(_t,ASSIGN);
		_t = _t.getFirstChild();
		id1 = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		AST tmp38_AST_in = (AST)_t;
		match(_t,ASSIG);
		_t = _t.getNextSibling();
		cG.addAssign(id1);
		expr(_t);
		_t = _retTree;
		cG.endAssign();
		_t = __t105;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void lit(AST _t) throws RecognitionException {
		
		AST lit_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST r = null;
		AST i = null;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case REAL_LITERAL:
		{
			r = (AST)_t;
			match(_t,REAL_LITERAL);
			_t = _t.getNextSibling();
			cG.addNumber(r);
			break;
		}
		case INT_LITERAL:
		{
			i = (AST)_t;
			match(_t,INT_LITERAL);
			_t = _t.getNextSibling();
			cG.addNumber(i);
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void access(AST _t) throws RecognitionException {
		
		AST access_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST id = null;
		
		AST __t122 = _t;
		AST tmp39_AST_in = (AST)_t;
		match(_t,ACCESS);
		_t = _t.getFirstChild();
		{
		id = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		cG.addIdent(this.getId(),id);
		{
		_loop125:
		do {
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case DOT:
			{
				AST tmp40_AST_in = (AST)_t;
				match(_t,DOT);
				_t = _t.getNextSibling();
				AST tmp41_AST_in = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
				break;
			}
			case ACCESS_PARAM:
			{
				access_param(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				break _loop125;
			}
			}
		} while (true);
		}
		}
		_t = __t122;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void access_param(AST _t) throws RecognitionException {
		
		AST access_param_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t127 = _t;
		AST tmp42_AST_in = (AST)_t;
		match(_t,ACCESS_PARAM);
		_t = _t.getFirstChild();
		{
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case IDENT:
		{
			AST tmp43_AST_in = (AST)_t;
			match(_t,IDENT);
			_t = _t.getNextSibling();
			{
			_loop130:
			do {
				if (_t==null) _t=ASTNULL;
				if ((_t.getType()==COMMA)) {
					AST tmp44_AST_in = (AST)_t;
					match(_t,COMMA);
					_t = _t.getNextSibling();
					AST tmp45_AST_in = (AST)_t;
					match(_t,IDENT);
					_t = _t.getNextSibling();
				}
				else {
					break _loop130;
				}
				
			} while (true);
			}
			break;
		}
		case 3:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		}
		_t = __t127;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"numeric\"",
		"\"string\"",
		"\"class\"",
		"\"main\"",
		"\"extends\"",
		"\"object\"",
		"\"method\"",
		"\"return\"",
		"\"if\"",
		"\"else\"",
		"\"for\"",
		"\"or\"",
		"\"and\"",
		"\"not\"",
		"\"print\"",
		"\"read\"",
		"\"true\"",
		"\"false\"",
		"INT_LITERAL",
		"REAL_LITERAL",
		"LETTER",
		"DIGIT",
		"UNDERSCORE",
		"IDENT",
		"SEMICOLON",
		"COMMA",
		"DOT",
		"COLON",
		"LEFT_PAREN",
		"RIGHT_PAREN",
		"LEFT_BRACE",
		"RIGHT_BRACE",
		"LEFT_BRACKET",
		"a right bracket (']')",
		"PLUS",
		"SUB",
		"STAR",
		"SLASH",
		"ASSIG",
		"EQUAL",
		"NOT_EQUAL",
		"GR_EQUAL",
		"LE_EQUAL",
		"GR",
		"LE",
		"NUMBER",
		"WS",
		"STRING_LITERAL",
		"LINE_COMMENT",
		"COMMENT",
		"PROGRAM",
		"VAR_DEC",
		"UN_MINUS",
		"BODY",
		"ASSIGN",
		"FOR_ST",
		"IF_ST",
		"PARAM",
		"ELSE_ST",
		"FOR_HEADER",
		"BASIC_VAR_DEC",
		"ACCESS",
		"ACCESS_PARAM",
		"RES_NOT"
	};
	
	}
	
