package cl.ucv.inf.mileppcompiler.compilers;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import cl.ucv.inf.mileppcompiler.Tool;
import cl.ucv.inf.mileppcompiler.compilers.programInfo.MileAttribute;

import antlr.collections.AST;

/**
 * Performs the code generation for the Mile++ language.
 * 
 * 
 * @author Ricardo Soto<br>
 * @since 1.5<br>
 */

public class CodeGenerator {
    
	
	private PrintWriter pW = null;
    protected String code = "";
    static private String PATH = "output/";
    private String fileName = "test";
    //to manage indentation
    private int glIndCounter = 0;
    

    public CodeGenerator() {    	
        this.buildFile();
    }
    
    public void buildFile() {
        this.createFile(PATH + fileName + ".java");
    }
    
    public void addClass(AST id) {
    	this.resetInd();
    	this.pln("class " + id.toString() + "() {");
    	this.addInd();
    } 
    
    public void endClass() {
    	this.subInd();
    	this.pln("}");
    }

    public void addReturn() {
    	this.p("return ");
    }
    
    public void endReturn() {
    	pW.println(";");
    }
    
    public void addMethod(AST type, AST id) {
    	this.pln("public " + this.typeFormat(type.toString()) + " " + id.toString()
    			+ "() {");
    	this.addInd();
    }
    
    public String typeFormat(String st) {
    	if(st.equals("numeric")) 
    		return "int";
    	else
    		return "String";
    }
    
    public void endMethod() {
    	this.subInd();
    	this.pln("}");
    }
    
    public void addAssign(AST id) {
    	this.p(id + "=");
    }
    
    public void endAssign() {
    	pW.println(";");
    }
    
    
    public void addPlus() {
    	pW.print("+");
    	
    }
    
    /**
     * Generates the code of an IDENT, additionally calls
     * to the getValue method, which is responsible for
     * replacing the IDENT by its corresponding value if 
     * it is possible.
     * 
     * @param idClass
     * @param id
     */
    public void addIdent(String idClass,AST id) {
    	pW.print(this.getValue(idClass,id.toString()));
    }
    
    /**
     * Gets the value of an IDENT is exists in order to
     * perform the constant propagation
     * 
     * @param idClass
     * @param st
     * @return st
     */
    public String getValue(String idClass,String st) {
    	MileAttribute mA = 
    		Tool.getmP().getClass(idClass).getAttFromId(st);
    	if(mA!=null)
    		if(mA.getValue()!=null)
    			return mA.getValue().toString();
    	return st;
    }
    
    
    public void addNumber(AST id) {
    	pW.print(id.toString());
    }
    
    public void end() {
       	this.closeFile();
    	
    }
 
    /**
     * Associates the print writer to an output file, the file name is given.
     *
     * @param st
     *            the name of the file
     */
    public void createFile(String st) {
        try {  
            FileWriter fW = new FileWriter(st);
            BufferedWriter bW = new BufferedWriter(fW);
            pW = new PrintWriter(bW);
        } catch (IOException ioe) {
            System.err.println("Path does not exist: '" + st + "'");
        }
    }

    /**
     * Closes the output file.
     */
    public void closeFile() {
    	pW.close();
    }

	/**
	 * @return the glIndCounter
	 */
	public int getGlIndCounter() {
		return glIndCounter;
	}

	/**
	 * @param glIndCounter the glIndCounter to set
	 */
	public void setGlIndCounter(int glIndCounter) {
		this.glIndCounter = glIndCounter;
	}
    
    
    public void pln(String st) {
    	pW.println(ind() + st);	
    }
    
    public void p(String st) {
    	pW.print(ind() + st);	
    }    

    
    public String ind(){
    	String st = "";
    	for (int i=1; i<=this.getGlIndCounter();i++){
    		st+=" ";
    	}
    	return st;
    }
    
    public void addInd(){
    	this.setGlIndCounter(getGlIndCounter()+2);
    }
    
    public void subInd(){
    	this.setGlIndCounter(getGlIndCounter()-2);
    }
    
    public void resetInd(){
    	this.setGlIndCounter(0);
    }
	
    
}


 