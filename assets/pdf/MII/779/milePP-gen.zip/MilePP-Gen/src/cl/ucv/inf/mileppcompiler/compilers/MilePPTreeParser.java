// $ANTLR : "MilePPTreeParser.g" -> "MilePPTreeParser.java"$

/**
 * Semantic analysis for the Mile++ Language.
 * 
 * @author Ricardo Soto
 * @since 1.5
 */

package cl.ucv.inf.mileppcompiler.compilers;


import antlr.TreeParser;
import antlr.Token;
import antlr.collections.AST;
import antlr.RecognitionException;
import antlr.ANTLRException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.collections.impl.BitSet;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;


public class MilePPTreeParser extends antlr.TreeParser       implements MilePPTreeParserTokenTypes
 {

private SemanticInspector   sI = new SemanticInspector();
private String classId = "";

	public void setId(AST id) {
		this.classId = id.toString();
	}
	
	public String getId() {
		return classId;
	}

public MilePPTreeParser() {
	tokenNames = _tokenNames;
}

	public final void program(AST _t) throws RecognitionException {
		
		AST program_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t1109 = _t;
		AST tmp1_AST_in = (AST)_t;
		match(_t,PROGRAM);
		_t = _t.getFirstChild();
		main_class_dec(_t);
		_t = _retTree;
		{
		_loop1111:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==CLASS_RW)) {
				class_dec(_t);
				_t = _retTree;
			}
			else {
				break _loop1111;
			}
			
		} while (true);
		}
		_t = __t1109;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void main_class_dec(AST _t) throws RecognitionException {
		
		AST main_class_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t1113 = _t;
		AST tmp2_AST_in = (AST)_t;
		match(_t,MAIN_RW);
		_t = _t.getFirstChild();
		class_dec(_t);
		_t = _retTree;
		_t = __t1113;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void class_dec(AST _t) throws RecognitionException {
		
		AST class_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST id1 = null;
		
		AST __t1115 = _t;
		AST tmp3_AST_in = (AST)_t;
		match(_t,CLASS_RW);
		_t = _t.getFirstChild();
		id1 = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		sI.addClass(id1);this.setId(id1);
		{
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case EXTENDS_RW:
		{
			AST tmp4_AST_in = (AST)_t;
			match(_t,EXTENDS_RW);
			_t = _t.getNextSibling();
			AST tmp5_AST_in = (AST)_t;
			match(_t,IDENT);
			_t = _t.getNextSibling();
			break;
		}
		case BODY:
		case PARAM:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		}
		{
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case PARAM:
		{
			param(_t);
			_t = _retTree;
			break;
		}
		case BODY:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		}
		class_body(_t);
		_t = _retTree;
		_t = __t1115;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void param(AST _t) throws RecognitionException {
		
		AST param_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t1119 = _t;
		AST tmp6_AST_in = (AST)_t;
		match(_t,PARAM);
		_t = _t.getFirstChild();
		type(_t);
		_t = _retTree;
		AST tmp7_AST_in = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		{
		_loop1121:
		do {
			if (_t==null) _t=ASTNULL;
			if ((_t.getType()==COMMA)) {
				AST tmp8_AST_in = (AST)_t;
				match(_t,COMMA);
				_t = _t.getNextSibling();
				type(_t);
				_t = _retTree;
				AST tmp9_AST_in = (AST)_t;
				match(_t,IDENT);
				_t = _t.getNextSibling();
			}
			else {
				break _loop1121;
			}
			
		} while (true);
		}
		_t = __t1119;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void class_body(AST _t) throws RecognitionException {
		
		AST class_body_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t1123 = _t;
		AST tmp10_AST_in = (AST)_t;
		match(_t,BODY);
		_t = _t.getFirstChild();
		var_dec(_t);
		_t = _retTree;
		method_dec(_t);
		_t = _retTree;
		_t = __t1123;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void type(AST _t) throws RecognitionException {
		
		AST type_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case NUMERIC_TYPE:
		case STRING_TYPE:
		{
			basic_type(_t);
			_t = _retTree;
			break;
		}
		case IDENT:
		{
			AST tmp11_AST_in = (AST)_t;
			match(_t,IDENT);
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void var_dec(AST _t) throws RecognitionException {
		
		AST var_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t1125 = _t;
		AST tmp12_AST_in = (AST)_t;
		match(_t,VAR_DEC);
		_t = _t.getFirstChild();
		{
		_loop1127:
		do {
			if (_t==null) _t=ASTNULL;
			switch ( _t.getType()) {
			case BASIC_VAR_DEC:
			{
				basic_var_dec(_t);
				_t = _retTree;
				break;
			}
			case OBJECT_RW:
			{
				object_dec(_t);
				_t = _retTree;
				break;
			}
			default:
			{
				break _loop1127;
			}
			}
		} while (true);
		}
		_t = __t1125;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void method_dec(AST _t) throws RecognitionException {
		
		AST method_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		_retTree = _t;
	}
	
	public final void basic_var_dec(AST _t) throws RecognitionException {
		
		AST basic_var_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		AST id = null;
		
		AST __t1129 = _t;
		AST tmp13_AST_in = (AST)_t;
		match(_t,BASIC_VAR_DEC);
		_t = _t.getFirstChild();
		basic_type(_t);
		_t = _retTree;
		id = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		sI.addAttribute(this.getId(),id);
		_t = __t1129;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void object_dec(AST _t) throws RecognitionException {
		
		AST object_dec_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		AST __t1131 = _t;
		AST tmp14_AST_in = (AST)_t;
		match(_t,OBJECT_RW);
		_t = _t.getFirstChild();
		AST tmp15_AST_in = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		AST tmp16_AST_in = (AST)_t;
		match(_t,IDENT);
		_t = _t.getNextSibling();
		_t = __t1131;
		_t = _t.getNextSibling();
		_retTree = _t;
	}
	
	public final void basic_type(AST _t) throws RecognitionException {
		
		AST basic_type_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		{
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case NUMERIC_TYPE:
		{
			AST tmp17_AST_in = (AST)_t;
			match(_t,NUMERIC_TYPE);
			_t = _t.getNextSibling();
			break;
		}
		case STRING_TYPE:
		{
			AST tmp18_AST_in = (AST)_t;
			match(_t,STRING_TYPE);
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		}
		_retTree = _t;
	}
	
	public final void expr(AST _t) throws RecognitionException {
		
		AST expr_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case OR_RW:
		{
			AST __t1137 = _t;
			AST tmp19_AST_in = (AST)_t;
			match(_t,OR_RW);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t1137;
			_t = _t.getNextSibling();
			break;
		}
		case AND_RW:
		{
			AST __t1138 = _t;
			AST tmp20_AST_in = (AST)_t;
			match(_t,AND_RW);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t1138;
			_t = _t.getNextSibling();
			break;
		}
		case EQUAL:
		{
			AST __t1139 = _t;
			AST tmp21_AST_in = (AST)_t;
			match(_t,EQUAL);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t1139;
			_t = _t.getNextSibling();
			break;
		}
		case GR_EQUAL:
		{
			AST __t1140 = _t;
			AST tmp22_AST_in = (AST)_t;
			match(_t,GR_EQUAL);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t1140;
			_t = _t.getNextSibling();
			break;
		}
		case NOT_EQUAL:
		{
			AST __t1141 = _t;
			AST tmp23_AST_in = (AST)_t;
			match(_t,NOT_EQUAL);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t1141;
			_t = _t.getNextSibling();
			break;
		}
		case GR:
		{
			AST __t1142 = _t;
			AST tmp24_AST_in = (AST)_t;
			match(_t,GR);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t1142;
			_t = _t.getNextSibling();
			break;
		}
		case LE:
		{
			AST __t1143 = _t;
			AST tmp25_AST_in = (AST)_t;
			match(_t,LE);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t1143;
			_t = _t.getNextSibling();
			break;
		}
		case PLUS:
		{
			AST __t1144 = _t;
			AST tmp26_AST_in = (AST)_t;
			match(_t,PLUS);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t1144;
			_t = _t.getNextSibling();
			break;
		}
		case SUB:
		{
			AST __t1145 = _t;
			AST tmp27_AST_in = (AST)_t;
			match(_t,SUB);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t1145;
			_t = _t.getNextSibling();
			break;
		}
		case STAR:
		{
			AST __t1146 = _t;
			AST tmp28_AST_in = (AST)_t;
			match(_t,STAR);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t1146;
			_t = _t.getNextSibling();
			break;
		}
		case SLASH:
		{
			AST __t1147 = _t;
			AST tmp29_AST_in = (AST)_t;
			match(_t,SLASH);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			expr(_t);
			_t = _retTree;
			_t = __t1147;
			_t = _t.getNextSibling();
			break;
		}
		case UN_MINUS:
		{
			AST __t1148 = _t;
			AST tmp30_AST_in = (AST)_t;
			match(_t,UN_MINUS);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			_t = __t1148;
			_t = _t.getNextSibling();
			break;
		}
		case RES_NOT:
		{
			AST __t1149 = _t;
			AST tmp31_AST_in = (AST)_t;
			match(_t,RES_NOT);
			_t = _t.getFirstChild();
			expr(_t);
			_t = _retTree;
			_t = __t1149;
			_t = _t.getNextSibling();
			break;
		}
		case IDENT:
		{
			AST tmp32_AST_in = (AST)_t;
			match(_t,IDENT);
			_t = _t.getNextSibling();
			break;
		}
		case INT_LITERAL:
		case REAL_LITERAL:
		{
			lit(_t);
			_t = _retTree;
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	public final void lit(AST _t) throws RecognitionException {
		
		AST lit_AST_in = (_t == ASTNULL) ? null : (AST)_t;
		
		if (_t==null) _t=ASTNULL;
		switch ( _t.getType()) {
		case REAL_LITERAL:
		{
			AST tmp33_AST_in = (AST)_t;
			match(_t,REAL_LITERAL);
			_t = _t.getNextSibling();
			break;
		}
		case INT_LITERAL:
		{
			AST tmp34_AST_in = (AST)_t;
			match(_t,INT_LITERAL);
			_t = _t.getNextSibling();
			break;
		}
		default:
		{
			throw new NoViableAltException(_t);
		}
		}
		_retTree = _t;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"numeric\"",
		"\"string\"",
		"\"class\"",
		"\"main\"",
		"\"extends\"",
		"\"object\"",
		"\"method\"",
		"\"return\"",
		"\"if\"",
		"\"else\"",
		"\"for\"",
		"\"or\"",
		"\"and\"",
		"\"not\"",
		"\"print\"",
		"\"read\"",
		"\"true\"",
		"\"false\"",
		"INT_LITERAL",
		"REAL_LITERAL",
		"LETTER",
		"DIGIT",
		"UNDERSCORE",
		"IDENT",
		"SEMICOLON",
		"COMMA",
		"DOT",
		"COLON",
		"LEFT_PAREN",
		"RIGHT_PAREN",
		"LEFT_BRACE",
		"RIGHT_BRACE",
		"LEFT_BRACKET",
		"a right bracket (']')",
		"PLUS",
		"SUB",
		"STAR",
		"SLASH",
		"ASSIG",
		"EQUAL",
		"NOT_EQUAL",
		"GR_EQUAL",
		"LE_EQUAL",
		"GR",
		"LE",
		"NUMBER",
		"WS",
		"STRING_LITERAL",
		"LINE_COMMENT",
		"COMMENT",
		"PROGRAM",
		"VAR_DEC",
		"UN_MINUS",
		"BODY",
		"ASSIGN",
		"FOR_ST",
		"IF_ST",
		"PARAM",
		"ELSE_ST",
		"FOR_HEADER",
		"BASIC_VAR_DEC",
		"ACCESS",
		"ACCESS_PARAM",
		"RES_NOT"
	};
	
	}
	
