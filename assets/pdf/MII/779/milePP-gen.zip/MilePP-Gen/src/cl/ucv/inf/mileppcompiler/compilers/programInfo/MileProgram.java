package cl.ucv.inf.mileppcompiler.compilers.programInfo;

import java.util.ArrayList;

/**
 * Stores the intermediate representation of a Mile++ program.
 * 
 * @author Ricardo Soto<br>
 * @since 1.5<br>
 */

public class MileProgram {

	private ArrayList<MileClass> mileClasses = new ArrayList<MileClass>();

	/**
	 * Adds the class to the programInfo
	 * 
	 * @param c
	 *           the AST containing the class.
	 */ 
	public void addClass(String c){		
		this.mileClasses.add(new MileClass(c));
	}
	
	/**
	 * Checks if the class exists
	 * 
	 * @param id
	 * @return true if the class is found; false otherwise
	 */
	public boolean contains(String id){
		for (MileClass mC : mileClasses) {
			if(mC.getId().equals(id))
				return true;
		}
		return false;
	}
	

	/**
	 * Adds the object o to the class c
	 * 
	 * @param c
	 * @param o
	 */
	public void addObjectToClass(String c, String o){
		MileClass mC = this.getClass(c);
		mC.addAtt(new MileAttribute(o));
	}

	/**
	 * Gets a class
	 * 
	 * @param id
	 * @return the class (if found); otherwise null
	 */
	public MileClass getClass(String id){
		for (MileClass mC : mileClasses) {
			if(mC.getId().equals(id))
				return mC;
		}
		return null;
	}

	/**
	 * @return the mileClasses
	 */
	public ArrayList<MileClass> getMileClasses() {
		return mileClasses;
	}

	
	public String toString(){
		String st = "";
		for (MileClass mC : this.getMileClasses())
			st+=mC.toString() + ",";
		return st;
	}
	
}
