package cl.ucv.inf.mileppcompiler.compilers;

import cl.ucv.inf.mileppcompiler.Tool;
import cl.ucv.inf.mileppcompiler.compilers.programInfo.MileClass;

import antlr.collections.AST;

/**
 * Performs the semantic checking for the Mile++ language.
 * 
 * 
 * @author Ricardo Soto<br>
 * @since 1.5<br>
 */

public class SemanticInspector {

	/**
	 * Adds the class to the programInfo
	 * 
	 * @param c
	 *           the AST containing the class.
	 */ 
	public void addClass(AST c) {
		if(Tool.getmP().contains(c.toString()))
			this.semanticError(c, "redefinition of class '" + c + "'");
		else
			Tool.getmP().addClass(c.toString());

	}

	
	/**
	 * Adds the attribute to the class
	 * 
	 * @param idClass, idAtt
	 *           the AST containing the id of the attribute.
	 */ 
	public void addAttribute(String idClass, AST idAtt) {
		MileClass mC = Tool.getmP().getClass(idClass); 
		if(mC.containsAtt(idAtt.toString()))
			this.semanticError(idAtt, "redefinition of attribute '" 
					+ idAtt + "'");
		else
			mC.addAttribute(idAtt.toString());
	}
	
	/**
	 * Checks a class extending itself
	 * 
	 * @param idClass
	 *           the AST containing the id of the class.
	 * @param idSuperClass
	 *           the AST containing the id of the superclass.
	 *           
	 */ 
	public void checkExtends(AST idClass, AST idSuperClass) {
		if(idClass.toString().equals(idSuperClass.toString()))
			this.semanticError(idClass, "Class '" + idClass.toString() + "' cannot extend itself");

	}
	
	/**
	 * Checks objects
	 * 
	 * @param var
	 *           the AST containing the variable.
	 */ 
	public void checkObject(AST idClass, AST idObject) {
		if(!Tool.getmP().contains(idClass.toString()))
			this.semanticError(idClass, "Class '" + idClass + "' is not defined");
		else
			Tool.getmP().addObjectToClass(idClass.toString(), idObject.toString());
	}

	public void addConstantIfExists(String classId, AST idAtt, AST value)  {
		if(this.isNumber(value.toString())){
				Tool.getmP().getClass(classId)
				.setAttributeValue(idAtt.toString(), value.toString());
		}
	} 
	
	
	public boolean isNumber(String s) {
		try {
			Double.parseDouble(s);
		}
		catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	
	
	public void semanticError(AST ast, String message)  {
		System.err.println(ast.getFilename() + ":" + 
				ast.getLine() + ":" + 
				ast.getColumn() + ": " + 
				message);
	} 
        
 
    
}


 