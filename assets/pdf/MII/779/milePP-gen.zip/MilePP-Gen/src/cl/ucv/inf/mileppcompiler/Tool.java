package cl.ucv.inf.mileppcompiler;

import java.io.FileInputStream;

import cl.ucv.inf.mileppcompiler.compilers.MilePPCodeGen;

import cl.ucv.inf.mileppcompiler.compilers.MilePPLexer;
import cl.ucv.inf.mileppcompiler.compilers.MilePPParser;
import cl.ucv.inf.mileppcompiler.compilers.MilePPTreeParser;
import cl.ucv.inf.mileppcompiler.compilers.MilePPTreeParser2ndPass;
import cl.ucv.inf.mileppcompiler.compilers.programInfo.MileProgram;

import antlr.collections.AST;
import antlr.debug.misc.ASTFrame;

/**
 * The main class of Mile++ 
 * 
 * @author Ricardo Soto
 * @since 1.5
 */


public class Tool {

    private static String fileName = "";
    private static FileInputStream fis = null;
    private static MileProgram mP = new MileProgram();
    



	public static void main(String args[]) { 
        try { 
            System.out.println("Parsing file...");
            setSourceFile(args);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Sets source file and arguments.
     * 
     * @param args
     */
    public static void setSourceFile(String args[]) {
        int i = args.length - 1;
        try {
            setFileName(args[i]);
            setFis(new FileInputStream(args[i])); 
            codeGeneration();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    
    /**
     * Tests the code generator.
     * 
     * @param args
     */
    public static void codeGeneration() {
    	try
    	{
    		MilePPLexer lexer = new MilePPLexer(fis);
    		lexer.setFilename(fileName);
    		lexer.setTokenObjectClass("antlraux.util.LexInfoToken");
    		MilePPParser parser = new MilePPParser(lexer);
            parser.setFilename(fileName);
            parser.program();
            AST ast = parser.getAST();
            final ASTFrame frame1 = new ASTFrame("", ast);
            frame1.setVisible(false);
            MilePPTreeParser treeParser = new MilePPTreeParser();
            treeParser.program(ast);
            MilePPTreeParser2ndPass treeParserSP = new MilePPTreeParser2ndPass();
            treeParserSP.program(ast);
            
            System.out.println("Code Generation...");
            MilePPCodeGen codeGen = new MilePPCodeGen();
            codeGen.program(ast);
            System.out.println("Ok...");
            
            
    	}
    	catch (Exception ex)
    	{
    		 ex.printStackTrace();
    	}
    }


    /**
     * @param fis The fis to set.
     */
    public static void setFis(FileInputStream fisIn) {
        fis = fisIn;
    }

    /**
     * @param fileName The fileName to set.
     */
    public static void setFileName(String fileNameIn) {
        fileName = fileNameIn;
    }
    
    public static MileProgram getmP() {
		return mP;
	}

	public static void setmP(MileProgram mP) {
		Tool.mP = mP;
	}

}

