class test1() {
  public int calc() {
    a=2;
    b=2+5;
    return b;
  }
}
