// $ANTLR : "MilePPParser.g" -> "MilePPParser.java"$

/**
 * Parser for the Mile language.
 * 
 * @author Ricardo Soto
 * @since 1.5
 */

package cl.ucv.inf.mileppcompiler.compilers;


public interface MilePPParserVocabTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int NUMERIC_TYPE = 4;
	int STRING_TYPE = 5;
	int CLASS_RW = 6;
	int MAIN_RW = 7;
	int EXTENDS_RW = 8;
	int OBJECT_RW = 9;
	int METHOD_RW = 10;
	int RETURN_RW = 11;
	int IF_RW = 12;
	int ELSE_RW = 13;
	int FOR_RW = 14;
	int OR_RW = 15;
	int AND_RW = 16;
	int NOT_RW = 17;
	int PRINT_RW = 18;
	int READ_RW = 19;
	int TRUE_LITERAL = 20;
	int FALSE_LITERAL = 21;
	int INT_LITERAL = 22;
	int REAL_LITERAL = 23;
	int LETTER = 24;
	int DIGIT = 25;
	int UNDERSCORE = 26;
	int IDENT = 27;
	int SEMICOLON = 28;
	int COMMA = 29;
	int DOT = 30;
	int COLON = 31;
	int LEFT_PAREN = 32;
	int RIGHT_PAREN = 33;
	int LEFT_BRACE = 34;
	int RIGHT_BRACE = 35;
	int LEFT_BRACKET = 36;
	int RIGHT_BRACKET = 37;
	int PLUS = 38;
	int SUB = 39;
	int STAR = 40;
	int SLASH = 41;
	int ASSIG = 42;
	int EQUAL = 43;
	int NOT_EQUAL = 44;
	int GR_EQUAL = 45;
	int LE_EQUAL = 46;
	int GR = 47;
	int LE = 48;
	int NUMBER = 49;
	int WS = 50;
	int STRING_LITERAL = 51;
	int LINE_COMMENT = 52;
	int COMMENT = 53;
	int PROGRAM = 54;
	int PARAM = 55;
	int UN_MINUS = 56;
}
