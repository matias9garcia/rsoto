// $ANTLR : "MilePPParser.g" -> "MilePPParser.java"$

/**
 * Parser for the Mile language.
 * 
 * @author Ricardo Soto
 * @since 1.5
 */

package cl.ucv.inf.mileppcompiler.compilers;


import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

public class MilePPParser extends antlr.LLkParser       implements MilePPParserVocabTokenTypes
 {

protected MilePPParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public MilePPParser(TokenBuffer tokenBuf) {
  this(tokenBuf,2);
}

protected MilePPParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public MilePPParser(TokenStream lexer) {
  this(lexer,2);
}

public MilePPParser(ParserSharedInputState state) {
  super(state,2);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void program() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST program_AST = null;
		
		main_class_dec();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop73:
		do {
			if ((LA(1)==CLASS_RW)) {
				class_dec();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop73;
			}
			
		} while (true);
		}
		program_AST = (AST)currentAST.root;
		program_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PROGRAM,"PROGRAM")).add(program_AST));
		currentAST.root = program_AST;
		currentAST.child = program_AST!=null &&program_AST.getFirstChild()!=null ?
			program_AST.getFirstChild() : program_AST;
		currentAST.advanceChildToEnd();
		program_AST = (AST)currentAST.root;
		returnAST = program_AST;
	}
	
	public final void main_class_dec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST main_class_dec_AST = null;
		
		AST tmp1_AST = null;
		tmp1_AST = astFactory.create(LT(1));
		astFactory.makeASTRoot(currentAST, tmp1_AST);
		match(MAIN_RW);
		class_dec();
		astFactory.addASTChild(currentAST, returnAST);
		main_class_dec_AST = (AST)currentAST.root;
		returnAST = main_class_dec_AST;
	}
	
	public final void class_dec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST class_dec_AST = null;
		
		AST tmp2_AST = null;
		tmp2_AST = astFactory.create(LT(1));
		astFactory.makeASTRoot(currentAST, tmp2_AST);
		match(CLASS_RW);
		AST tmp3_AST = null;
		tmp3_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp3_AST);
		match(IDENT);
		{
		switch ( LA(1)) {
		case EXTENDS_RW:
		{
			AST tmp4_AST = null;
			tmp4_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp4_AST);
			match(EXTENDS_RW);
			AST tmp5_AST = null;
			tmp5_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp5_AST);
			match(IDENT);
			break;
		}
		case LEFT_PAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(LEFT_PAREN);
		{
		switch ( LA(1)) {
		case IDENT:
		{
			param();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case RIGHT_PAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RIGHT_PAREN);
		match(LEFT_BRACE);
		class_body();
		astFactory.addASTChild(currentAST, returnAST);
		match(RIGHT_BRACE);
		class_dec_AST = (AST)currentAST.root;
		returnAST = class_dec_AST;
	}
	
	public final void param() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST param_AST = null;
		
		type();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp10_AST = null;
		tmp10_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp10_AST);
		match(IDENT);
		{
		_loop80:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp11_AST = null;
				tmp11_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp11_AST);
				match(COMMA);
				type();
				astFactory.addASTChild(currentAST, returnAST);
				AST tmp12_AST = null;
				tmp12_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp12_AST);
				match(IDENT);
			}
			else {
				break _loop80;
			}
			
		} while (true);
		}
		param_AST = (AST)currentAST.root;
		param_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PARAM,"PARAM")).add(param_AST));
		currentAST.root = param_AST;
		currentAST.child = param_AST!=null &&param_AST.getFirstChild()!=null ?
			param_AST.getFirstChild() : param_AST;
		currentAST.advanceChildToEnd();
		param_AST = (AST)currentAST.root;
		returnAST = param_AST;
	}
	
	public final void class_body() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST class_body_AST = null;
		
		class_body_AST = (AST)currentAST.root;
		returnAST = class_body_AST;
	}
	
	public final void type() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST type_AST = null;
		
		type_AST = (AST)currentAST.root;
		returnAST = type_AST;
	}
	
	public final void basic_type() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST basic_type_AST = null;
		
		{
		switch ( LA(1)) {
		case NUMERIC_TYPE:
		{
			AST tmp13_AST = null;
			tmp13_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp13_AST);
			match(NUMERIC_TYPE);
			break;
		}
		case STRING_TYPE:
		{
			AST tmp14_AST = null;
			tmp14_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp14_AST);
			match(STRING_TYPE);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		basic_type_AST = (AST)currentAST.root;
		returnAST = basic_type_AST;
	}
	
	public final void expr() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expr_AST = null;
		
		expAND();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop87:
		do {
			if ((LA(1)==OR_RW)) {
				AST tmp15_AST = null;
				tmp15_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp15_AST);
				match(OR_RW);
				expAND();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop87;
			}
			
		} while (true);
		}
		expr_AST = (AST)currentAST.root;
		returnAST = expr_AST;
	}
	
	public final void expAND() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expAND_AST = null;
		
		expCons();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop90:
		do {
			if ((LA(1)==AND_RW)) {
				AST tmp16_AST = null;
				tmp16_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp16_AST);
				match(AND_RW);
				expCons();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop90;
			}
			
		} while (true);
		}
		expAND_AST = (AST)currentAST.root;
		returnAST = expAND_AST;
	}
	
	public final void expCons() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expCons_AST = null;
		
		expSum();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop94:
		do {
			if (((LA(1) >= EQUAL && LA(1) <= LE))) {
				{
				switch ( LA(1)) {
				case EQUAL:
				{
					AST tmp17_AST = null;
					tmp17_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp17_AST);
					match(EQUAL);
					break;
				}
				case LE_EQUAL:
				{
					AST tmp18_AST = null;
					tmp18_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp18_AST);
					match(LE_EQUAL);
					break;
				}
				case GR_EQUAL:
				{
					AST tmp19_AST = null;
					tmp19_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp19_AST);
					match(GR_EQUAL);
					break;
				}
				case NOT_EQUAL:
				{
					AST tmp20_AST = null;
					tmp20_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp20_AST);
					match(NOT_EQUAL);
					break;
				}
				case GR:
				{
					AST tmp21_AST = null;
					tmp21_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp21_AST);
					match(GR);
					break;
				}
				case LE:
				{
					AST tmp22_AST = null;
					tmp22_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp22_AST);
					match(LE);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expSum();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop94;
			}
			
		} while (true);
		}
		expCons_AST = (AST)currentAST.root;
		returnAST = expCons_AST;
	}
	
	public final void expSum() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expSum_AST = null;
		
		expProduct();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop98:
		do {
			if ((LA(1)==PLUS||LA(1)==SUB)) {
				{
				switch ( LA(1)) {
				case PLUS:
				{
					AST tmp23_AST = null;
					tmp23_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp23_AST);
					match(PLUS);
					break;
				}
				case SUB:
				{
					AST tmp24_AST = null;
					tmp24_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp24_AST);
					match(SUB);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expProduct();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop98;
			}
			
		} while (true);
		}
		expSum_AST = (AST)currentAST.root;
		returnAST = expSum_AST;
	}
	
	public final void expProduct() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expProduct_AST = null;
		
		expMinus();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop102:
		do {
			if ((LA(1)==STAR||LA(1)==SLASH)) {
				{
				switch ( LA(1)) {
				case STAR:
				{
					AST tmp25_AST = null;
					tmp25_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp25_AST);
					match(STAR);
					break;
				}
				case SLASH:
				{
					AST tmp26_AST = null;
					tmp26_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp26_AST);
					match(SLASH);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expMinus();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop102;
			}
			
		} while (true);
		}
		expProduct_AST = (AST)currentAST.root;
		returnAST = expProduct_AST;
	}
	
	public final void expMinus() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expMinus_AST = null;
		
		switch ( LA(1)) {
		case SUB:
		{
			{
			match(SUB);
			expNot();
			astFactory.addASTChild(currentAST, returnAST);
			}
			expMinus_AST = (AST)currentAST.root;
			expMinus_AST=(AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(UN_MINUS,"UN_MINUS")).add(expMinus_AST)) ;
			currentAST.root = expMinus_AST;
			currentAST.child = expMinus_AST!=null &&expMinus_AST.getFirstChild()!=null ?
				expMinus_AST.getFirstChild() : expMinus_AST;
			currentAST.advanceChildToEnd();
			expMinus_AST = (AST)currentAST.root;
			break;
		}
		case NOT_RW:
		case INT_LITERAL:
		case REAL_LITERAL:
		case IDENT:
		case LEFT_PAREN:
		case PLUS:
		{
			{
			{
			switch ( LA(1)) {
			case PLUS:
			{
				match(PLUS);
				break;
			}
			case NOT_RW:
			case INT_LITERAL:
			case REAL_LITERAL:
			case IDENT:
			case LEFT_PAREN:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			expNot();
			astFactory.addASTChild(currentAST, returnAST);
			}
			expMinus_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = expMinus_AST;
	}
	
	public final void expNot() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expNot_AST = null;
		
		{
		switch ( LA(1)) {
		case NOT_RW:
		{
			AST tmp29_AST = null;
			tmp29_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp29_AST);
			match(NOT_RW);
			break;
		}
		case INT_LITERAL:
		case REAL_LITERAL:
		case IDENT:
		case LEFT_PAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case IDENT:
		{
			AST tmp30_AST = null;
			tmp30_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp30_AST);
			match(IDENT);
			break;
		}
		case INT_LITERAL:
		case REAL_LITERAL:
		{
			lit();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LEFT_PAREN:
		{
			{
			match(LEFT_PAREN);
			expr();
			astFactory.addASTChild(currentAST, returnAST);
			match(RIGHT_PAREN);
			}
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		expNot_AST = (AST)currentAST.root;
		returnAST = expNot_AST;
	}
	
	public final void lit() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST lit_AST = null;
		
		switch ( LA(1)) {
		case REAL_LITERAL:
		{
			AST tmp33_AST = null;
			tmp33_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp33_AST);
			match(REAL_LITERAL);
			lit_AST = (AST)currentAST.root;
			break;
		}
		case INT_LITERAL:
		{
			AST tmp34_AST = null;
			tmp34_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp34_AST);
			match(INT_LITERAL);
			lit_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = lit_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"numeric\"",
		"\"string\"",
		"\"class\"",
		"\"main\"",
		"\"extends\"",
		"\"object\"",
		"\"method\"",
		"\"return\"",
		"\"if\"",
		"\"else\"",
		"\"for\"",
		"\"or\"",
		"\"and\"",
		"\"not\"",
		"\"print\"",
		"\"read\"",
		"\"true\"",
		"\"false\"",
		"INT_LITERAL",
		"REAL_LITERAL",
		"LETTER",
		"DIGIT",
		"UNDERSCORE",
		"IDENT",
		"SEMICOLON",
		"COMMA",
		"DOT",
		"COLON",
		"LEFT_PAREN",
		"RIGHT_PAREN",
		"LEFT_BRACE",
		"RIGHT_BRACE",
		"LEFT_BRACKET",
		"a right bracket (']')",
		"PLUS",
		"SUB",
		"STAR",
		"SLASH",
		"ASSIG",
		"EQUAL",
		"NOT_EQUAL",
		"GR_EQUAL",
		"LE_EQUAL",
		"GR",
		"LE",
		"NUMBER",
		"WS",
		"STRING_LITERAL",
		"LINE_COMMENT",
		"COMMENT",
		"PROGRAM",
		"PARAM",
		"UN_MINUS"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	
	}
