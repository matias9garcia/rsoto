package cl.ucv.inf.mileppcompiler;

import java.io.FileInputStream;

import cl.ucv.inf.mileppcompiler.compilers.MilePPLexer;
import cl.ucv.inf.mileppcompiler.compilers.MilePPParser;
import cl.ucv.inf.mileppcompiler.compilers.MilePPTreeParser;
import cl.ucv.inf.mileppcompiler.compilers.MilePPTreeParser2ndPass;
import cl.ucv.inf.mileppcompiler.compilers.programInfo.mileProgram;

import antlr.collections.AST;
import antlr.debug.misc.ASTFrame;

/**
 * The main class of Mile++ 
 * 
 * @author Ricardo Soto
 * @since 1.5
 */


public class Tool {

    private static String fileName = "";
    private static FileInputStream fis = null;
    private static mileProgram mP = new mileProgram();
    



	public static void main(String args[]) { 
        try { 
            System.out.println("Parsing file...");
            setSourceFile(args);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Sets source file and arguments.
     * 
     * @param args
     */
    public static void setSourceFile(String args[]) {
        int i = args.length - 1;
        try {
            setFileName(args[i]);
            setFis(new FileInputStream(args[i])); 
            semanticTest();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    
    /**
     * Tests the semantic checking.
     * 
     * @param args
     */
    public static void semanticTest() {
    	try
    	{
    		MilePPLexer lexer = new MilePPLexer(fis);
    		lexer.setFilename(fileName);
    		lexer.setTokenObjectClass("antlraux.util.LexInfoToken");
    		MilePPParser parser = new MilePPParser(lexer);
            parser.setFilename(fileName);
            parser.program();
            AST ast = parser.getAST();
            final ASTFrame frame1 = new ASTFrame("", ast);
            frame1.setVisible(false);
            MilePPTreeParser treeParser = new MilePPTreeParser();
            treeParser.program(ast);
            MilePPTreeParser2ndPass treeParserSP = new MilePPTreeParser2ndPass();
            treeParserSP.program(ast);
            
            
    	}
    	catch (Exception ex)
    	{
    		System.err.println("Error leyendo tokens: " + ex.toString());
    	}
    }


    /**
     * @param fis The fis to set.
     */
    public static void setFis(FileInputStream fisIn) {
        fis = fisIn;
    }

    /**
     * @param fileName The fileName to set.
     */
    public static void setFileName(String fileNameIn) {
        fileName = fileNameIn;
    }
    
    public static mileProgram getmP() {
		return mP;
	}

	public static void setmP(mileProgram mP) {
		Tool.mP = mP;
	}

}

