package cl.ucv.inf.mileppcompiler.compilers;

import cl.ucv.inf.mileppcompiler.Tool;

import antlr.collections.AST;

/**
 * Performs the semantic checking for the Mile++ language.
 * 
 * 
 * @author Ricardo Soto<br>
 * @since 1.5<br>
 */

public class SemanticInspector {

	/**
	 * Adds the class to the programInfo
	 * 
	 * @param c
	 *           the AST containing the class.
	 */ 
	public void addClass(AST c) {
		if(Tool.getmP().contains(c.toString()))
			this.semanticError(c, "redefinition of class '" + c + "'");
		else
			Tool.getmP().addClass(c.toString());

	}

	/**
	 * Checks a class extending itself
	 * 
	 * @param idClass
	 *           the AST containing the id of the class.
	 * @param idSuperClass
	 *           the AST containing the id of the superclass.
	 *           
	 */ 
	public void checkExtends(AST idClass, AST idSuperClass) {
		if(idClass.toString().equals(idSuperClass.toString()))
			this.semanticError(idClass, "Class '" + idClass.toString() + "' cannot extend itself");

	}
	
	/**
	 * Checks objects
	 * 
	 * @param var
	 *           the AST containing the variable.
	 */ 
	public void checkObject(AST idClass, AST idObject) {
		if(!Tool.getmP().contains(idClass.toString()))
			this.semanticError(idClass, "Class '" + idClass + "' is not defined");
		else
			Tool.getmP().addObjectToClass(idClass.toString(), idObject.toString());
	}
	
	
	
	public void semanticError(AST ast, String message)  {
		System.err.println(ast.getFilename() + ":" + 
				ast.getLine() + ":" + 
				ast.getColumn() + ": " + 
				message);
	} 
        
 
    
}


 