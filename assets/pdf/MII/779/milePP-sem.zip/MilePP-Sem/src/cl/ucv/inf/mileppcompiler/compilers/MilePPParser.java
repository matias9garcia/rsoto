// $ANTLR : "MilePPParser.g" -> "MilePPParser.java"$

/**
 * Parser for the Mile language.
 * 
 * @author Ricardo Soto
 * @since 1.5
 */

package cl.ucv.inf.mileppcompiler.compilers;


import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

public class MilePPParser extends antlr.LLkParser       implements MilePPParserVocabTokenTypes
 {

protected MilePPParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public MilePPParser(TokenBuffer tokenBuf) {
  this(tokenBuf,2);
}

protected MilePPParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public MilePPParser(TokenStream lexer) {
  this(lexer,2);
}

public MilePPParser(ParserSharedInputState state) {
  super(state,2);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void program() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST program_AST = null;
		
		main_class_dec();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop172:
		do {
			if ((LA(1)==CLASS_RW)) {
				class_dec();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop172;
			}
			
		} while (true);
		}
		program_AST = (AST)currentAST.root;
		program_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PROGRAM,"PROGRAM")).add(program_AST));
		currentAST.root = program_AST;
		currentAST.child = program_AST!=null &&program_AST.getFirstChild()!=null ?
			program_AST.getFirstChild() : program_AST;
		currentAST.advanceChildToEnd();
		program_AST = (AST)currentAST.root;
		returnAST = program_AST;
	}
	
	public final void main_class_dec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST main_class_dec_AST = null;
		
		AST tmp1_AST = null;
		tmp1_AST = astFactory.create(LT(1));
		astFactory.makeASTRoot(currentAST, tmp1_AST);
		match(MAIN_RW);
		class_dec();
		astFactory.addASTChild(currentAST, returnAST);
		main_class_dec_AST = (AST)currentAST.root;
		returnAST = main_class_dec_AST;
	}
	
	public final void class_dec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST class_dec_AST = null;
		
		AST tmp2_AST = null;
		tmp2_AST = astFactory.create(LT(1));
		astFactory.makeASTRoot(currentAST, tmp2_AST);
		match(CLASS_RW);
		AST tmp3_AST = null;
		tmp3_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp3_AST);
		match(IDENT);
		{
		switch ( LA(1)) {
		case EXTENDS_RW:
		{
			AST tmp4_AST = null;
			tmp4_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp4_AST);
			match(EXTENDS_RW);
			AST tmp5_AST = null;
			tmp5_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp5_AST);
			match(IDENT);
			break;
		}
		case LEFT_PAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(LEFT_PAREN);
		{
		switch ( LA(1)) {
		case NUMERIC_TYPE:
		case STRING_TYPE:
		case IDENT:
		{
			param();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case RIGHT_PAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RIGHT_PAREN);
		match(LEFT_BRACE);
		class_body();
		astFactory.addASTChild(currentAST, returnAST);
		match(RIGHT_BRACE);
		class_dec_AST = (AST)currentAST.root;
		returnAST = class_dec_AST;
	}
	
	public final void param() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST param_AST = null;
		
		type();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp10_AST = null;
		tmp10_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp10_AST);
		match(IDENT);
		{
		_loop179:
		do {
			if ((LA(1)==COMMA)) {
				AST tmp11_AST = null;
				tmp11_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp11_AST);
				match(COMMA);
				type();
				astFactory.addASTChild(currentAST, returnAST);
				AST tmp12_AST = null;
				tmp12_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp12_AST);
				match(IDENT);
			}
			else {
				break _loop179;
			}
			
		} while (true);
		}
		param_AST = (AST)currentAST.root;
		param_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PARAM,"PARAM")).add(param_AST));
		currentAST.root = param_AST;
		currentAST.child = param_AST!=null &&param_AST.getFirstChild()!=null ?
			param_AST.getFirstChild() : param_AST;
		currentAST.advanceChildToEnd();
		param_AST = (AST)currentAST.root;
		returnAST = param_AST;
	}
	
	public final void class_body() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST class_body_AST = null;
		
		var_dec();
		astFactory.addASTChild(currentAST, returnAST);
		method_dec();
		astFactory.addASTChild(currentAST, returnAST);
		class_body_AST = (AST)currentAST.root;
		class_body_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(BODY,"BODY")).add(class_body_AST));
		currentAST.root = class_body_AST;
		currentAST.child = class_body_AST!=null &&class_body_AST.getFirstChild()!=null ?
			class_body_AST.getFirstChild() : class_body_AST;
		currentAST.advanceChildToEnd();
		class_body_AST = (AST)currentAST.root;
		returnAST = class_body_AST;
	}
	
	public final void type() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST type_AST = null;
		
		switch ( LA(1)) {
		case NUMERIC_TYPE:
		case STRING_TYPE:
		{
			basic_type();
			astFactory.addASTChild(currentAST, returnAST);
			type_AST = (AST)currentAST.root;
			break;
		}
		case IDENT:
		{
			AST tmp13_AST = null;
			tmp13_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp13_AST);
			match(IDENT);
			type_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = type_AST;
	}
	
	public final void basic_type() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST basic_type_AST = null;
		
		{
		switch ( LA(1)) {
		case NUMERIC_TYPE:
		{
			AST tmp14_AST = null;
			tmp14_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp14_AST);
			match(NUMERIC_TYPE);
			break;
		}
		case STRING_TYPE:
		{
			AST tmp15_AST = null;
			tmp15_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp15_AST);
			match(STRING_TYPE);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		basic_type_AST = (AST)currentAST.root;
		returnAST = basic_type_AST;
	}
	
	public final void var_dec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST var_dec_AST = null;
		
		{
		_loop184:
		do {
			switch ( LA(1)) {
			case NUMERIC_TYPE:
			case STRING_TYPE:
			{
				basic_var_dec();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case OBJECT_RW:
			{
				object_dec();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				break _loop184;
			}
			}
		} while (true);
		}
		var_dec_AST = (AST)currentAST.root;
		var_dec_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(VAR_DEC,"VAR_DEC")).add(var_dec_AST));
		currentAST.root = var_dec_AST;
		currentAST.child = var_dec_AST!=null &&var_dec_AST.getFirstChild()!=null ?
			var_dec_AST.getFirstChild() : var_dec_AST;
		currentAST.advanceChildToEnd();
		var_dec_AST = (AST)currentAST.root;
		returnAST = var_dec_AST;
	}
	
	public final void basic_var_dec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST basic_var_dec_AST = null;
		
		basic_type();
		astFactory.addASTChild(currentAST, returnAST);
		AST tmp16_AST = null;
		tmp16_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp16_AST);
		match(IDENT);
		match(SEMICOLON);
		basic_var_dec_AST = (AST)currentAST.root;
		basic_var_dec_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(BASIC_VAR_DEC,"BASIC_VAR_DEC")).add(basic_var_dec_AST));
		currentAST.root = basic_var_dec_AST;
		currentAST.child = basic_var_dec_AST!=null &&basic_var_dec_AST.getFirstChild()!=null ?
			basic_var_dec_AST.getFirstChild() : basic_var_dec_AST;
		currentAST.advanceChildToEnd();
		basic_var_dec_AST = (AST)currentAST.root;
		returnAST = basic_var_dec_AST;
	}
	
	public final void object_dec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST object_dec_AST = null;
		
		AST tmp18_AST = null;
		tmp18_AST = astFactory.create(LT(1));
		astFactory.makeASTRoot(currentAST, tmp18_AST);
		match(OBJECT_RW);
		AST tmp19_AST = null;
		tmp19_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp19_AST);
		match(IDENT);
		AST tmp20_AST = null;
		tmp20_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp20_AST);
		match(IDENT);
		match(SEMICOLON);
		object_dec_AST = (AST)currentAST.root;
		returnAST = object_dec_AST;
	}
	
	public final void method_dec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST method_dec_AST = null;
		
		{
		_loop191:
		do {
			if ((LA(1)==METHOD_RW)) {
				AST tmp22_AST = null;
				tmp22_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp22_AST);
				match(METHOD_RW);
				type();
				astFactory.addASTChild(currentAST, returnAST);
				AST tmp23_AST = null;
				tmp23_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp23_AST);
				match(IDENT);
				match(LEFT_PAREN);
				{
				switch ( LA(1)) {
				case NUMERIC_TYPE:
				case STRING_TYPE:
				case IDENT:
				{
					param();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				case RIGHT_PAREN:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				match(RIGHT_PAREN);
				match(LEFT_BRACE);
				var_dec();
				astFactory.addASTChild(currentAST, returnAST);
				body();
				astFactory.addASTChild(currentAST, returnAST);
				return_st();
				astFactory.addASTChild(currentAST, returnAST);
				match(RIGHT_BRACE);
			}
			else {
				break _loop191;
			}
			
		} while (true);
		}
		method_dec_AST = (AST)currentAST.root;
		returnAST = method_dec_AST;
	}
	
	public final void body() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST body_AST = null;
		
		{
		_loop196:
		do {
			switch ( LA(1)) {
			case IDENT:
			{
				assign();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case IF_RW:
			case FOR_RW:
			{
				st();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case PRINT_RW:
			{
				print();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case READ_RW:
			{
				read();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				break _loop196;
			}
			}
		} while (true);
		}
		body_AST = (AST)currentAST.root;
		body_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(BODY,"BODY")).add(body_AST));
		currentAST.root = body_AST;
		currentAST.child = body_AST!=null &&body_AST.getFirstChild()!=null ?
			body_AST.getFirstChild() : body_AST;
		currentAST.advanceChildToEnd();
		body_AST = (AST)currentAST.root;
		returnAST = body_AST;
	}
	
	public final void return_st() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST return_st_AST = null;
		
		AST tmp28_AST = null;
		tmp28_AST = astFactory.create(LT(1));
		astFactory.makeASTRoot(currentAST, tmp28_AST);
		match(RETURN_RW);
		expr();
		astFactory.addASTChild(currentAST, returnAST);
		match(SEMICOLON);
		return_st_AST = (AST)currentAST.root;
		returnAST = return_st_AST;
	}
	
	public final void expr() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expr_AST = null;
		
		expAND();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop210:
		do {
			if ((LA(1)==OR_RW)) {
				AST tmp30_AST = null;
				tmp30_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp30_AST);
				match(OR_RW);
				expAND();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop210;
			}
			
		} while (true);
		}
		expr_AST = (AST)currentAST.root;
		returnAST = expr_AST;
	}
	
	public final void assign() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST assign_AST = null;
		
		AST tmp31_AST = null;
		tmp31_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp31_AST);
		match(IDENT);
		AST tmp32_AST = null;
		tmp32_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp32_AST);
		match(ASSIG);
		expr();
		astFactory.addASTChild(currentAST, returnAST);
		match(SEMICOLON);
		assign_AST = (AST)currentAST.root;
		assign_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ASSIGN,"ASSIGN")).add(assign_AST));
		currentAST.root = assign_AST;
		currentAST.child = assign_AST!=null &&assign_AST.getFirstChild()!=null ?
			assign_AST.getFirstChild() : assign_AST;
		currentAST.advanceChildToEnd();
		assign_AST = (AST)currentAST.root;
		returnAST = assign_AST;
	}
	
	public final void st() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST st_AST = null;
		
		{
		switch ( LA(1)) {
		case FOR_RW:
		{
			for_st();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case IF_RW:
		{
			if_st();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		st_AST = (AST)currentAST.root;
		returnAST = st_AST;
	}
	
	public final void print() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST print_AST = null;
		
		AST tmp34_AST = null;
		tmp34_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp34_AST);
		match(PRINT_RW);
		match(LEFT_PAREN);
		AST tmp36_AST = null;
		tmp36_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp36_AST);
		match(STRING_LITERAL);
		match(COMMA);
		AST tmp38_AST = null;
		tmp38_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp38_AST);
		match(IDENT);
		match(RIGHT_PAREN);
		match(SEMICOLON);
		print_AST = (AST)currentAST.root;
		returnAST = print_AST;
	}
	
	public final void read() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST read_AST = null;
		
		AST tmp41_AST = null;
		tmp41_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp41_AST);
		match(READ_RW);
		match(LEFT_PAREN);
		AST tmp43_AST = null;
		tmp43_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp43_AST);
		match(IDENT);
		match(RIGHT_PAREN);
		match(SEMICOLON);
		read_AST = (AST)currentAST.root;
		returnAST = read_AST;
	}
	
	public final void for_st() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST for_st_AST = null;
		
		AST tmp46_AST = null;
		tmp46_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp46_AST);
		match(FOR_RW);
		for_header();
		astFactory.addASTChild(currentAST, returnAST);
		match(LEFT_BRACE);
		body();
		astFactory.addASTChild(currentAST, returnAST);
		match(RIGHT_BRACE);
		for_st_AST = (AST)currentAST.root;
		for_st_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(FOR_ST,"FOR_ST")).add(for_st_AST));
		currentAST.root = for_st_AST;
		currentAST.child = for_st_AST!=null &&for_st_AST.getFirstChild()!=null ?
			for_st_AST.getFirstChild() : for_st_AST;
		currentAST.advanceChildToEnd();
		for_st_AST = (AST)currentAST.root;
		returnAST = for_st_AST;
	}
	
	public final void if_st() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST if_st_AST = null;
		
		AST tmp49_AST = null;
		tmp49_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp49_AST);
		match(IF_RW);
		match(LEFT_PAREN);
		if_cond();
		astFactory.addASTChild(currentAST, returnAST);
		match(RIGHT_PAREN);
		match(LEFT_BRACE);
		body();
		astFactory.addASTChild(currentAST, returnAST);
		match(RIGHT_BRACE);
		{
		switch ( LA(1)) {
		case ELSE_RW:
		{
			else_st();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case RETURN_RW:
		case IF_RW:
		case FOR_RW:
		case PRINT_RW:
		case READ_RW:
		case IDENT:
		case RIGHT_BRACE:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		if_st_AST = (AST)currentAST.root;
		if_st_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(IF_ST,"IF_ST")).add(if_st_AST));
		currentAST.root = if_st_AST;
		currentAST.child = if_st_AST!=null &&if_st_AST.getFirstChild()!=null ?
			if_st_AST.getFirstChild() : if_st_AST;
		currentAST.advanceChildToEnd();
		if_st_AST = (AST)currentAST.root;
		returnAST = if_st_AST;
	}
	
	public final void for_header() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST for_header_AST = null;
		
		match(LEFT_PAREN);
		for_init();
		astFactory.addASTChild(currentAST, returnAST);
		for_cond();
		astFactory.addASTChild(currentAST, returnAST);
		match(SEMICOLON);
		AST tmp56_AST = null;
		tmp56_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp56_AST);
		match(INT_LITERAL);
		match(RIGHT_PAREN);
		for_header_AST = (AST)currentAST.root;
		for_header_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(FOR_HEADER,"FOR_HEADER")).add(for_header_AST));
		currentAST.root = for_header_AST;
		currentAST.child = for_header_AST!=null &&for_header_AST.getFirstChild()!=null ?
			for_header_AST.getFirstChild() : for_header_AST;
		currentAST.advanceChildToEnd();
		for_header_AST = (AST)currentAST.root;
		returnAST = for_header_AST;
	}
	
	public final void for_init() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST for_init_AST = null;
		
		assign();
		astFactory.addASTChild(currentAST, returnAST);
		for_init_AST = (AST)currentAST.root;
		returnAST = for_init_AST;
	}
	
	public final void for_cond() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST for_cond_AST = null;
		
		expr();
		astFactory.addASTChild(currentAST, returnAST);
		for_cond_AST = (AST)currentAST.root;
		returnAST = for_cond_AST;
	}
	
	public final void if_cond() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST if_cond_AST = null;
		
		expr();
		astFactory.addASTChild(currentAST, returnAST);
		if_cond_AST = (AST)currentAST.root;
		returnAST = if_cond_AST;
	}
	
	public final void else_st() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST else_st_AST = null;
		
		AST tmp58_AST = null;
		tmp58_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp58_AST);
		match(ELSE_RW);
		match(LEFT_BRACE);
		body();
		astFactory.addASTChild(currentAST, returnAST);
		match(RIGHT_BRACE);
		else_st_AST = (AST)currentAST.root;
		else_st_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ELSE_ST,"ELSE_ST")).add(else_st_AST));
		currentAST.root = else_st_AST;
		currentAST.child = else_st_AST!=null &&else_st_AST.getFirstChild()!=null ?
			else_st_AST.getFirstChild() : else_st_AST;
		currentAST.advanceChildToEnd();
		else_st_AST = (AST)currentAST.root;
		returnAST = else_st_AST;
	}
	
	public final void expAND() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expAND_AST = null;
		
		expCons();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop213:
		do {
			if ((LA(1)==AND_RW)) {
				AST tmp61_AST = null;
				tmp61_AST = astFactory.create(LT(1));
				astFactory.makeASTRoot(currentAST, tmp61_AST);
				match(AND_RW);
				expCons();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop213;
			}
			
		} while (true);
		}
		expAND_AST = (AST)currentAST.root;
		returnAST = expAND_AST;
	}
	
	public final void expCons() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expCons_AST = null;
		
		expSum();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop217:
		do {
			if (((LA(1) >= EQUAL && LA(1) <= LE))) {
				{
				switch ( LA(1)) {
				case EQUAL:
				{
					AST tmp62_AST = null;
					tmp62_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp62_AST);
					match(EQUAL);
					break;
				}
				case LE_EQUAL:
				{
					AST tmp63_AST = null;
					tmp63_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp63_AST);
					match(LE_EQUAL);
					break;
				}
				case GR_EQUAL:
				{
					AST tmp64_AST = null;
					tmp64_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp64_AST);
					match(GR_EQUAL);
					break;
				}
				case NOT_EQUAL:
				{
					AST tmp65_AST = null;
					tmp65_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp65_AST);
					match(NOT_EQUAL);
					break;
				}
				case GR:
				{
					AST tmp66_AST = null;
					tmp66_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp66_AST);
					match(GR);
					break;
				}
				case LE:
				{
					AST tmp67_AST = null;
					tmp67_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp67_AST);
					match(LE);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expSum();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop217;
			}
			
		} while (true);
		}
		expCons_AST = (AST)currentAST.root;
		returnAST = expCons_AST;
	}
	
	public final void expSum() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expSum_AST = null;
		
		expProduct();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop221:
		do {
			if ((LA(1)==PLUS||LA(1)==SUB)) {
				{
				switch ( LA(1)) {
				case PLUS:
				{
					AST tmp68_AST = null;
					tmp68_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp68_AST);
					match(PLUS);
					break;
				}
				case SUB:
				{
					AST tmp69_AST = null;
					tmp69_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp69_AST);
					match(SUB);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expProduct();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop221;
			}
			
		} while (true);
		}
		expSum_AST = (AST)currentAST.root;
		returnAST = expSum_AST;
	}
	
	public final void expProduct() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expProduct_AST = null;
		
		expMinus();
		astFactory.addASTChild(currentAST, returnAST);
		{
		_loop225:
		do {
			if ((LA(1)==STAR||LA(1)==SLASH)) {
				{
				switch ( LA(1)) {
				case STAR:
				{
					AST tmp70_AST = null;
					tmp70_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp70_AST);
					match(STAR);
					break;
				}
				case SLASH:
				{
					AST tmp71_AST = null;
					tmp71_AST = astFactory.create(LT(1));
					astFactory.makeASTRoot(currentAST, tmp71_AST);
					match(SLASH);
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				expMinus();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				break _loop225;
			}
			
		} while (true);
		}
		expProduct_AST = (AST)currentAST.root;
		returnAST = expProduct_AST;
	}
	
	public final void expMinus() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expMinus_AST = null;
		
		switch ( LA(1)) {
		case SUB:
		{
			{
			match(SUB);
			expNot();
			astFactory.addASTChild(currentAST, returnAST);
			}
			expMinus_AST = (AST)currentAST.root;
			expMinus_AST=(AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(UN_MINUS,"UN_MINUS")).add(expMinus_AST)) ;
			currentAST.root = expMinus_AST;
			currentAST.child = expMinus_AST!=null &&expMinus_AST.getFirstChild()!=null ?
				expMinus_AST.getFirstChild() : expMinus_AST;
			currentAST.advanceChildToEnd();
			expMinus_AST = (AST)currentAST.root;
			break;
		}
		case NOT_RW:
		case INT_LITERAL:
		case REAL_LITERAL:
		case IDENT:
		case LEFT_PAREN:
		case PLUS:
		{
			{
			{
			switch ( LA(1)) {
			case PLUS:
			{
				match(PLUS);
				break;
			}
			case NOT_RW:
			case INT_LITERAL:
			case REAL_LITERAL:
			case IDENT:
			case LEFT_PAREN:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			expNot();
			astFactory.addASTChild(currentAST, returnAST);
			}
			expMinus_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = expMinus_AST;
	}
	
	public final void expNot() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST expNot_AST = null;
		
		{
		switch ( LA(1)) {
		case NOT_RW:
		{
			AST tmp74_AST = null;
			tmp74_AST = astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp74_AST);
			match(NOT_RW);
			break;
		}
		case INT_LITERAL:
		case REAL_LITERAL:
		case IDENT:
		case LEFT_PAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		{
		switch ( LA(1)) {
		case IDENT:
		{
			access();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case INT_LITERAL:
		case REAL_LITERAL:
		{
			lit();
			astFactory.addASTChild(currentAST, returnAST);
			break;
		}
		case LEFT_PAREN:
		{
			{
			match(LEFT_PAREN);
			expr();
			astFactory.addASTChild(currentAST, returnAST);
			match(RIGHT_PAREN);
			}
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		expNot_AST = (AST)currentAST.root;
		returnAST = expNot_AST;
	}
	
	public final void access() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST access_AST = null;
		
		AST tmp77_AST = null;
		tmp77_AST = astFactory.create(LT(1));
		astFactory.addASTChild(currentAST, tmp77_AST);
		match(IDENT);
		{
		_loop237:
		do {
			switch ( LA(1)) {
			case DOT:
			{
				AST tmp78_AST = null;
				tmp78_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp78_AST);
				match(DOT);
				AST tmp79_AST = null;
				tmp79_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp79_AST);
				match(IDENT);
				break;
			}
			case LEFT_PAREN:
			{
				access_param();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				break _loop237;
			}
			}
		} while (true);
		}
		access_AST = (AST)currentAST.root;
		access_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ACCESS,"ACCESS")).add(access_AST));
		currentAST.root = access_AST;
		currentAST.child = access_AST!=null &&access_AST.getFirstChild()!=null ?
			access_AST.getFirstChild() : access_AST;
		currentAST.advanceChildToEnd();
		access_AST = (AST)currentAST.root;
		returnAST = access_AST;
	}
	
	public final void lit() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST lit_AST = null;
		
		switch ( LA(1)) {
		case REAL_LITERAL:
		{
			AST tmp80_AST = null;
			tmp80_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp80_AST);
			match(REAL_LITERAL);
			lit_AST = (AST)currentAST.root;
			break;
		}
		case INT_LITERAL:
		{
			AST tmp81_AST = null;
			tmp81_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp81_AST);
			match(INT_LITERAL);
			lit_AST = (AST)currentAST.root;
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		returnAST = lit_AST;
	}
	
	public final void access_param() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST access_param_AST = null;
		
		match(LEFT_PAREN);
		{
		switch ( LA(1)) {
		case IDENT:
		{
			AST tmp83_AST = null;
			tmp83_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp83_AST);
			match(IDENT);
			{
			_loop241:
			do {
				if ((LA(1)==COMMA)) {
					AST tmp84_AST = null;
					tmp84_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp84_AST);
					match(COMMA);
					AST tmp85_AST = null;
					tmp85_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp85_AST);
					match(IDENT);
				}
				else {
					break _loop241;
				}
				
			} while (true);
			}
			break;
		}
		case RIGHT_PAREN:
		{
			break;
		}
		default:
		{
			throw new NoViableAltException(LT(1), getFilename());
		}
		}
		}
		match(RIGHT_PAREN);
		access_param_AST = (AST)currentAST.root;
		access_param_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(ACCESS_PARAM,"ACCESS_PARAM")).add(access_param_AST));
		currentAST.root = access_param_AST;
		currentAST.child = access_param_AST!=null &&access_param_AST.getFirstChild()!=null ?
			access_param_AST.getFirstChild() : access_param_AST;
		currentAST.advanceChildToEnd();
		access_param_AST = (AST)currentAST.root;
		returnAST = access_param_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"\"numeric\"",
		"\"string\"",
		"\"class\"",
		"\"main\"",
		"\"extends\"",
		"\"object\"",
		"\"method\"",
		"\"return\"",
		"\"if\"",
		"\"else\"",
		"\"for\"",
		"\"or\"",
		"\"and\"",
		"\"not\"",
		"\"print\"",
		"\"read\"",
		"\"true\"",
		"\"false\"",
		"INT_LITERAL",
		"REAL_LITERAL",
		"LETTER",
		"DIGIT",
		"UNDERSCORE",
		"IDENT",
		"SEMICOLON",
		"COMMA",
		"DOT",
		"COLON",
		"LEFT_PAREN",
		"RIGHT_PAREN",
		"LEFT_BRACE",
		"RIGHT_BRACE",
		"LEFT_BRACKET",
		"a right bracket (']')",
		"PLUS",
		"SUB",
		"STAR",
		"SLASH",
		"ASSIG",
		"EQUAL",
		"NOT_EQUAL",
		"GR_EQUAL",
		"LE_EQUAL",
		"GR",
		"LE",
		"NUMBER",
		"WS",
		"STRING_LITERAL",
		"LINE_COMMENT",
		"COMMENT",
		"PROGRAM",
		"VAR_DEC",
		"UN_MINUS",
		"BODY",
		"ASSIGN",
		"FOR_ST",
		"IF_ST",
		"PARAM",
		"ELSE_ST",
		"FOR_HEADER",
		"BASIC_VAR_DEC",
		"ACCESS",
		"ACCESS_PARAM"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	
	}
