package cl.ucv.inf.mileppcompiler.compilers.programInfo;

import java.util.ArrayList;

/**
 * Stores the intermediate representation of a Mile++ class.
 *  
 * @author Ricardo Soto<br>
 * @since 1.5<br>
 */

public class mileClass {

	private String id;
	private ArrayList<mileAttribute> mileAttributes = new ArrayList<mileAttribute>();
	
	/**
	 * @param id
	 */
	public mileClass(String id) {
		super();
		this.id = id;
	}

	/**
	 * Adds an attribute to the class
	 * 
	 * @param a
	 *           the mileAttribute.
	 */ 
	public void addAtt(mileAttribute a){
		this.mileAttributes.add(a);
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the mileAttributes
	 */
	public ArrayList<mileAttribute> getMileAttributes() {
		return mileAttributes;
	}

	/**
	 * @param mileAttributes the mileAttributes to set
	 */
	public void setMileAttributes(ArrayList<mileAttribute> mileAttributes) {
		this.mileAttributes = mileAttributes;
	}

	
	
}
