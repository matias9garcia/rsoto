package cl.ucv.inf.milecompiler;

import java.io.FileInputStream;

import cl.ucv.inf.milecompiler.compilers.MileLexer;
import cl.ucv.inf.milecompiler.compilers.MileParser;
import cl.ucv.inf.milecompiler.compilers.MileTreeParser;

import antlr.collections.AST;
import antlr.debug.misc.ASTFrame;


/**
 * The main class of the Mile Language
 * 
 * @author Ricardo Soto
 * @since 1.5
 */


public class Tool {

    private static String fileName = "";
    private static FileInputStream fis = null;

    public static void main(String args[]) { 
        try { 
            System.out.println("Parsing file...");
            setSourceFile(args);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Set source file and arguments.
     * 
     * @param args
     */
    public static void setSourceFile(String args[]) {
        int i = args.length - 1;
        try {
            setFileName(args[i]);
            setFis(new FileInputStream(args[i])); 
            SemanticTest();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    
    /**
     * Tests the semantic checking.
     * 
     * @param args
     */
    public static void SemanticTest() {
    	try
    	{
    		MileLexer lexer = new MileLexer(fis);
    		lexer.setFilename(fileName);
    		lexer.setTokenObjectClass("antlraux.util.LexInfoToken");
    		MileParser parser = new MileParser(lexer);
            parser.setFilename(fileName);
            parser.program();
            AST ast = parser.getAST();
            final ASTFrame frame1 = new ASTFrame("", ast);
            frame1.setVisible(false);
            MileTreeParser treeParser = new MileTreeParser();
            treeParser.program(ast);
            
            
    	}
    	catch (Exception ex)
    	{
    		System.err.println("Error leyendo tokens: " + ex.toString());
    	}
    }


    /**
     * @param fis The fis to set.
     */
    public static void setFis(FileInputStream fisIn) {
        fis = fisIn;
    }

    /**
     * @param fileName The fileName to set.
     */
    public static void setFileName(String fileNameIn) {
        fileName = fileNameIn;
    }

}

