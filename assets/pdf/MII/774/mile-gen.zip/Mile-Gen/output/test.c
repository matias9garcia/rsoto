#include <stdio.h>

void main()
{
  int a;
  int b;
}
