// $ANTLR : "MileLexer.g" -> "MileLexer.java"$

/**
 * Lexer for the Mile language.
 * 
 * @author Ricardo Soto
 * @since 1.5
 */

package cl.ucv.inf.milecompiler.compilers;

public interface MileLexerVocabTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int BEGIN_RW = 4;
	int LETTER = 5;
	int DIGIT = 6;
	int UNDERSCORE = 7;
	int IDENT = 8;
	int WS = 9;
}
