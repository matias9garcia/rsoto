package cl.ucv.inf.milecompiler;

import java.io.FileInputStream;

import cl.ucv.inf.milecompiler.compilers.MileLexer;
import antlr.Token;
import antlr.TokenStreamException;


/**
 * The main class of the Mile Language
 * 
 * @author Ricardo Soto
 * @since 1.5
 */


public class Tool {

    private static String fileName = "";
    private static FileInputStream fis = null;

    public static void main(String args[]) { 
        try { 
            System.out.println("Scanning file...");
            setSourceFile(args);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * Set source file and arguments.
     * 
     * @param args
     */
    public static void setSourceFile(String args[]) {
        int i = args.length - 1;
        try {
            setFileName(args[i]);
            setFis(new FileInputStream(args[i])); 
            lexicTest();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    
    /**
     * Tests the lexer.
     * 
     * @param args
     */
    public static void lexicTest() {
    	try
    	{

    		MileLexer lexer = new MileLexer(fis);
    		lexer.setFilename(fileName);
    		lexer.setTokenObjectClass("antlraux.util.LexInfoToken");
    		Token tok = lexer.nextToken();
    		while(tok.getType() != Token.EOF_TYPE)
    		{
    			System.out.println( tok.getFilename() + ":" +
    					tok.getLine() + ":" +
    					tok.getColumn() + ": " +
    					tok.getText());
    			tok = lexer.nextToken();
    		}
    	
    	}
    	catch (TokenStreamException tse)
    	{
    		System.err.println("Error leyendo tokens: " + tse.toString());
    	}
    }


    /**
     * @param fis The fis to set.
     */
    public static void setFis(FileInputStream fisIn) {
        fis = fisIn;
    }

    /**
     * @param fileName The fileName to set.
     */
    public static void setFileName(String fileNameIn) {
        fileName = fileNameIn;
    }

}

